'use strict';
var ocb = ocb || {};

ocb.restcli = (function (){
	let client = {
		contentType: {
			formurlencoded: "application/x-www-form-urlencoded",
			json: "application/json",
			multipart: "multipart/form-data",
			text: "text/plain"
		}
	};

	var getAjaxOpt = function(method, url, data, contentType, isAsync, sucCallback, errCallback, res, isPreloaderShow){
		return {
			type: method,
			url: url,
			datatype: 'json',
			contentType : contentType,
			data: data,
			async : isAsync,
			success:function(response){
				res = response;
				if(isPreloaderShow === true){
					ocb.preloader.hide();
				}
				if(typeof res === 'undefined' || !res){
					res =  {code:'err.wclient.800', message:'unknown.'};
				}

				if(typeof res.code === 'undefined' || !res.code){
					res.code='err.wclient.801';
				}

				if(res.code === 'OK'){
					if(typeof sucCallback === 'function' && sucCallback != null){
						sucCallback.call(this, res);
					}
				}else{
					if(typeof errCallback === 'function' && errCallback != null){
						errCallback.call(this, res);
					}
				}
			},
			error : function(e){
				if(isPreloaderShow === true){
					ocb.preloader.hide();
				}
				var res;
				if(typeof e === 'undefined' || !e){
					res = {code:'err.wclient.999', message:'unknown.'};
				}else{
					if(typeof e.responseText !== 'undefined'){
						var errRes;
						try{
							errRes = JSON.parse(e.responseText);
						}catch(ee){}

						if(typeof errRes !== 'undefined' && typeof errRes.code !== 'undefined'){
							res = errRes;
						}else{
							res = {code:'err.wclient.'+(typeof e.status !== 'undefined' ? e.status : '998'), message:''+ (typeof e.statusText !== 'undefined' ? ''+ e.statusText +'' : 'Unknown Error.')};
						}
					}else{
						res = {code:'err.wclient.'+(typeof e.status !== 'undefined' ? e.status : '997'), message:''+ (typeof e.statusText !== 'undefined' ? ''+ e.statusText +'' : 'Unknown Error.')};
					}
				}
				
				try{
					printTrace('error >>', JSON.stringify(e));
				}catch(_e){
					printTrace('error >>', e);
				}
				if(typeof errCallback === 'function' && errCallback != null){
					errCallback.call(this, (typeof res !== 'undefined' ? res:{code:'err.wclient.996', message:'Unknown Error.'}));
				}
			}
		}
	}
		
	client.exchange = function(method, url, data, contentType, isAsync, isPreloaderShow, sucCallback, errCallback){
		if(typeof isPreloaderShow === 'undefined' || isPreloaderShow == null){
			isPreloaderShow = true;
		}

		if(isPreloaderShow === true){
			ocb.preloader.show();
		}

		var res;
		var opt = getAjaxOpt(method, url, data, contentType, isAsync, sucCallback, errCallback, res, isPreloaderShow);
		
		$.ajax(opt);
		
		if(typeof isAsync !== 'undefined' && isAsync === true){
			return res;
		}
	};
	// application/x-www-form-urlencoded,
	client.exchangeAsync = function(method, url, data, contentType, isPreloaderShow, sucCallback, errCallback){
		if(typeof isPreloaderShow === 'undefined' || isPreloaderShow == null){
			isPreloaderShow = true;
		}
		if(isPreloaderShow === true){
			ocb.preloader.show();
		}

		var res;
		var opt = getAjaxOpt(method, url, data, contentType, true, sucCallback, errCallback, res, isPreloaderShow);
		
		$.ajax(opt);
	};
	
	client.exchangeSync = function(method, url, data, contentType, isPreloaderShow, sucCallback, errCallback){
		if(typeof isPreloaderShow === 'undefined' || isPreloaderShow == null){
			isPreloaderShow = true;
		}

		if(isPreloaderShow === true){
			ocb.preloader.show();
		}

		var res;
		var opt = getAjaxOpt(method, url, data, contentType, false, sucCallback, errCallback, res, isPreloaderShow);
		
		$.ajax(opt);
		return res
	};

	return client;
})();
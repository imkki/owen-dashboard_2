var ocb = ocb || {};
ocb.wscli = (function (){
	let c = {}
	let stompClient;
	let isConnected = false;
	let fnShowPriMessage;

	c.init = function(fnShowPri){
		fnShowPriMessage = fnShowPri;
	}
	let onConnected = function(frame){
		setConnected(true);
		printTrace('this.stompClient: ', frame);
		stompClient.subscribe('/user/octopic/web.message.private.'+ G_grpId, showPriMessage);
		printTrace('Connected: ' + frame);
	}
	let setConnected = function(connected){
		this.isConnected = true;
	}
	let checkLive = function(message){
		printTrace('>> checkLive: ', message);
		if(stompClient != null && stompClient.connected == false) {
			setConnected(false);
			printTrace(">> disconnected");
			setTimeout(c.open, 10000);
		}
	}
	let showPriMessage = function(message) {
		printTrace('>>[PRI]received: '+ message.body);
		let rcvObj = JSON.parse(message.body);
		let msgObj = rcvObj && rcvObj.message ? rcvObj.message : '';
		if(typeof fnShowPriMessage === 'function'){
			fnShowPriMessage.call(this, msgObj)
		}
	}
	c.open = function(){
		let socket = new SockJS(page_context_path +'/ws/connet');
	    stompClient = Stomp.over(socket);
		stompClient.connect({}, function(frame){
			printTrace('>> open socket: ', frame);
			onConnected(frame)
		}, checkLive);
	}
	c.close = function() {
		printTrace(">> [disConnection] ", stompClient);
		if(stompClient != null && stompClient.connected == true) {
	    	stompClient.disconnect();
			stompClient = null;
	    }
	}
	return c;
})();
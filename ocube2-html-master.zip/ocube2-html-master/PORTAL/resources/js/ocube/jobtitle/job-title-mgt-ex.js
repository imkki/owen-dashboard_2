var jobtilteMgt = (function () {
    let job = {};
    let d_cmpnyId;
    let g_msg;

    job.jdDataGrid;
    job.jdProperties = {};
    job.job_jd = {
        resources: []
    }

    job.datagrid1;
    job.SBGridProperties1 = {};
    job.job_data1 = {
        resources: []
    }

    job.datagrid2;
    job.SBGridProperties2 = {};
    job.job_data2 = {
        resources: []
    }

    job.job_nmgrid;
    job.jobNMGridProperties = {};
    job.jobNM_data = {
        resources: []
    }
    job.job_tabDept = [];
    job.selectUSEJsonDataTemp = [
        {
            text: "전체",
            value: "all"
        },
        {
            text: "활성",
            value: "inactive"
        },
        {
            text: "비활성",
            value: "active"
        }
    ]

    job.getSelectUSEJsonDataTemp = function () {
        return selectUSEJsonDataTemp;
    }

    job.selectCompanyJsonData = [
        {
            text: "회사이름1",
            value: "com1"
        },
        {
            text: "회사이름2",
            value: "com2"
        }
    ];

    job.radioJsonData = [
        {text: "사용", value: "Y"},
        {text: "미사용", value: "N"}
    ];

    job.init = function (globalOpt) {
        g_msg = globalOpt.springMsg;
        d_cmpnyId = globalOpt.cmpnyId;

       job.job_tabDept.push({
            "id": "0",
            "pid": "-1",
            "order": "1",
            "text": g_msg.tab.jd,
            "targetid": "JD_tab",
            "targetvalue": "JD"
        })
        job.job_tabDept.push({
            "id": "1",
            "pid": "-1",
            "order": "2",
            "text": g_msg.tab.jt,
            "targetid": "JT_tab",
            "targetvalue": "JT"
        })
        job.job_tabDept.push({
            "id": "2",
            "pid": "-1",
            "order": "3",
            "text": g_msg.tab.jo,
            "targetid": "JO_tab",
            "targetvalue": "JO"
        })
        SBUxMethod.refresh('jobtab');

        renderComp(this);
        initDataLoad(this);
        attechEvent(this);
    }

    let renderComp = function (obj) {
        jobTitleCreateGrid();

        jobTitleNameCreateGrid("job_name_list", "job_name_list1", "job_name_list2");
    }


    let initDataLoad = function (obj) {
        let param = {};
        param.cmpnyId = d_cmpnyId;
        param.gbCd = "JD";

        selectJOBList(param);
    }

    let attechEvent = function (obj) {
        job.jdDataGrid.bind('click', gridJobClick1);
        job.datagrid1.bind('click', gridJobClick1);
        job.datagrid2.bind('click', gridJobClick1);
    }

    job.cgTabClick = function () {
        let param = {};
        param.cmpnyId = d_cmpnyId;

        if (SBUxMethod.get('jobtab') === 'JD_tab') {
            param.gbCd = "JD";
            selectJOBList(param, "JD");
        } else if (SBUxMethod.get('jobtab') === 'JT_tab') {
            jobTitleCreateGrid1();
            param.gbCd = "JT";
            selectJOBList(param, "JT");
        } else {
            jobTitleCreateGrid2();
            param.gbCd = "JO";
            selectJOBList(param, "JO");
        }
    }

    // 직위 gird
    let jobTitleCreateGrid = function () {

        job.jdProperties.parentid = 'job_title_list';
        job.jdProperties.id = 'jobtilteMgt.jdDataGrid';
        job.jdProperties.jsonref = 'jobtilteMgt.job_jd.resources';
        job.jdProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        job.jdProperties.columns = [
            {
                caption: [''],
                ref: 'use_yn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'checkbox',
                typeinfo: {
                    checkedvalue: 'T',
                    uncheckedvalue: 'F',
                    fixedcellcheckbox: {usemode: true, rowindex: 1, deletecaption: false}
                }
            },
            {
                caption: [g_msg.jobJdGridCol.sortSn],
                ref: 'sortSn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.jobJdCd],
                ref: 'rspofcId',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.langName],
                ref: 'rspofcNm',
                width: '30%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.useYn],
                ref: 'useYn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            }
        ]
        job.jdDataGrid = _SBGrid.create(job.jdProperties);
    };

    //직책 gird
    let jobTitleCreateGrid1 = function () {

        job.SBGridProperties1.parentid = 'job_title_list1';
        job.SBGridProperties1.id = 'jobtilteMgt.datagrid1';
        job.SBGridProperties1.jsonref = 'jobtilteMgt.job_data1.resources';
        job.SBGridProperties1.emptyrecords = '데이터가 존재하지 않습니다.';
        job.SBGridProperties1.columns = [
            {
                caption: [''],
                ref: 'use_yn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'checkbox',
                typeinfo: {
                    checkedvalue: 'T',
                    uncheckedvalue: 'F',
                    fixedcellcheckbox: {usemode: true, rowindex: 1, deletecaption: false}
                }
            },
            {
                caption: [g_msg.jobJdGridCol.sortSn],
                ref: 'sortSn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.jobJtCd],
                ref: 'rspofcId',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.langName],
                ref: 'rspofcNm',
                width: '30%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.useYn],
                ref: 'useYn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            }
        ]
        job.datagrid1 = _SBGrid.create(job.SBGridProperties1);
    };

    //직종 그리드
    let jobTitleCreateGrid2 = function () {
        job.SBGridProperties2.id = 'jobtilteMgt.datagrid2';
        job.SBGridProperties2.jsonref = 'jobtilteMgt.job_data2.resources';
        job.SBGridProperties2.emptyrecords = '데이터가 존재하지 않습니다.';
        job.SBGridProperties2.columns = [
            {
                caption: [''],
                ref: 'use_yn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'checkbox',
                typeinfo: {
                    checkedvalue: 'T',
                    uncheckedvalue: 'F',
                    fixedcellcheckbox: {usemode: true, rowindex: 1, deletecaption: false}
                }
            },
            {
                caption: [g_msg.jobJdGridCol.sortSn],
                ref: 'sortSn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.jobJoCd],
                ref: 'rspofcId',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.langName],
                ref: 'rspofcNm',
                width: '30%',
                style: 'text-align:center',
                type: 'output'
            },
            {
                caption: [g_msg.jobJdGridCol.useYn],
                ref: 'useYn',
                width: '17.5%',
                style: 'text-align:center',
                type: 'output'
            }
        ]

        job.datagrid2 = _SBGrid.create(job.SBGridProperties2);

    };

    // 한/영 언어 gird
    let jobTitleNameCreateGrid = function (divId) {
        job.jobNMGridProperties.parentid = divId;
        job.jobNMGridProperties.id = 'jobtilteMgt.job_nmgrid';
        job.jobNMGridProperties.jsonref = 'jobtilteMgt.jobNM_data.resources';
        job.jobNMGridProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        job.jobNMGridProperties.columns = [
            {
                caption: [g_msg.jobJdGridCol.lang],
                ref: 'langCd',
                width: '30%',
                style: 'text-align:center',
                type: 'output',
                format: {
                    type: 'custom'
                    , callback: formatJobNmLangText
                }
            },
            {
                caption: [g_msg.jobJdGridCol.langName],
                ref: 'rspofcNm',
                width: '70%',
                style: 'text-align:center',
                type: 'input'
            }
        ]
        job.job_nmgrid = _SBGrid.create(job.jobNMGridProperties);
    };
    // 한/영 언어 구분
    let formatJobNmLangText = function (val) {
        var text = '';
        switch (val) {
            case 'ko':
                text = '한글';
                break;
            case 'en':
                text = '영어';
                break;
            default:
                break;
        }
        return text;
    }
    // list 목록 select [list]
    let selectJOBList = function (param, paramtype) {
        let type = paramtype;
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/list', JSON.stringify(
            param), 'application/json', true,
            function (res) {

                if (res.code === 'OK') {
                    let retObj = res.data;

                    if (type === 'JD') {
                        job.job_jd.resources = retObj;
                        job.jdDataGrid.refresh();
                    } else if (type === 'JT') {
                        job.job_data1.resources = retObj;
                        job.datagrid1.refresh();
                    } else {
                        job.job_data2.resources = retObj;
                        job.datagrid2.refresh();

                    }
                }

            },
            function (res) {
                printError('정보를 조회하는데 실패했습니다.');
                return false;
            });
    }


    let girdClick = function (){

        let param = {};

        if (SBUxMethod.get('jobtab') === 'JD_tab') {
            let grid = job.jdDataGrid;
            let nRow = grid.getRow();
            let nCol = grid.getCol();
            let lowdata = grid.getRowData(nRow);

            param.gbCd = "JD";
            selectJOBList(param, "JD");
        } else if (SBUxMethod.get('jobtab') === 'JT_tab') {
            let grid = job.jdDataGrid;
            let nRow = grid.getRow();
            let nCol = grid.getCol();
            let lowdata = grid.getRowData(nRow);

            jobTitleCreateGrid1();
            param.gbCd = "JT";
            selectJOBList(param, "JT");
        } else {
            let grid = job.jdDataGrid;
            let nRow = grid.getRow();
            let nCol = grid.getCol();
            let lowdata = grid.getRowData(nRow);


            jobTitleCreateGrid2();
            param.gbCd = "JO";
            selectJOBList(param, "JO");
        }

    }
    // 우측 세부정보 [get]
    let gridJobClick1 = function () {

        let grid = job.jdDataGrid;
        let nRow = grid.getRow();
        let nCol = grid.getCol();
        let lowdata = grid.getRowData(nRow);

        let param = {};

        param.cmpnyId = lowdata.cmpnyId;
        param.rspofcId = lowdata.rspofcId;
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/get', JSON.stringify(
            param), 'application/json', true,

            function (res) {
                SBUxMethod.set("job_code", res.data.rspofcId); //직무코드
                SBUxMethod.set("langCd", res.data.langCd); //언어설정
                SBUxMethod.set("job_sortSn", res.data.sortSn); //정렬순서
                SBUxMethod.set("job_useYn", res.data.useYn); //라디오 상태

                job.jobNM_data.resources = res.data.rspofcNms;
                job.job_nmgrid.refresh();
            },
            function (res) {
                ocb.cmm.errMsgHandler(res);
                return false;
            });

    }
    // 직위/직책 set
    job.jobSetBtn = function () {

        let param = {};

        let nRow = job.jdDataGrid.getRow();
        let lowdata = job.jdDataGrid.getRowData(nRow, true);

        let langList = job.job_nmgrid.getGridDataAll();
        let sortSn = SBUxMethod.get('job_sortSn');
        let useYn = SBUxMethod.get('job_useYn');
        let rspofcId = SBUxMethod.get('job_code');


        if (!rspofcId) {
            alert('직위코드는 필수 입니다.');
            SBUxMethod.focus('job_code');
            return false;
        }

        let chkYn = false;  // 처음 초기값

        langList.forEach(function (ele) {    // 리스트 값 체크
            if (ele.rspofcNm != '') {    // 값이 하나라도 입력되어있으면 true
                chkYn = true;
            }
        });

        if (!chkYn) {
            alert('명칭은 필수 입니다.');
        }

        if (job.tabJsonData.id = '0') {
            param.gbCd = "JD";
        } else if (job.tabJsonData.id = '1') {
            param.gbCd = "JT";
        } else {
            param.gbCd = "JO";
        }

        param.cmpnyId = d_cmpnyId;
        param.rspofcNms = langList;
        param.sortSn = sortSn;
        param.useYn = useYn;
        param.rspofcId = rspofcId;
        param.rspofcNm = lowdata.rspofcNm;

        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/set',
            JSON.stringify(param), 'application/json', true,
            function (res) {
                if (res.code === "OK") {
                    if (res.message === "Success.") {
                        alert("정보 수정에 성공하였습니다.");
                    }
                }
            },
            function (res) {
                ocb.cmm.errMsgHandler(res);
                alert("정보 수정에 실패하였습니다.")
                return false;
            });

    }

// 직위 remove - 단일 삭제

    job.jobClickRemoveBtn = function () {
        let param = {};
        let nRow = job.jdDataGrid.getRow();
        let lowdata = job.jdDataGrid.getRowData(nRow, true);

        if (confirm("선택한 항목을 삭제하시겠습니까?")) {
            param.cmpnyId = lowdata.cmpnyId;
            param.rspofcIds = [lowdata.rspofcId];
            job.removeJobTitle(param);
        }
    }

    // 직위 - 체크 박스 다중 삭제 -api 추가 후 진행 예정

    job.jobMultiRemoveBtn = function () {
        let param = {};
        let ckhList = job.jdDataGrid.getCheckedRowData(0);

        if (ckhList.length <= 0) {
            alert('삭제할 항목을 선택해 주세요.');
            return false;
        }
        if (confirm("선택한 항목을 삭제하시겠습니까?")) {
            let removeList = [];

            ckhList.forEach(function (ele) {
                var obj = {
                    rspofcIds: ele.data.rspofcId
                }
                removeList.push($.extend(true, {}, obj));
            })
            param.cmpnyId = d_cmpnyId;
            param.rspofcIds = removeList;
            job.removeJobTitle(param);
        } else {
            return false;
        }
    }
    // 삭제 api
    job.removeJobTitle = function (param) {
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/remove', JSON.stringify(param), 'application/json', true, function (res) { // success callback
            if (res.code === 'OK') {
                alert('삭제 되었습니다.');

                // res.data 결과 값 추가
                job.jdDataGrid.refresh();

            } else {
                alert('삭제 되지 않았습니다.');
            }
        }, function (res) {
            console.log('res >>> ', res);
            ocb.cmm.errMsgHandler(res);

            alert('삭제 실패하였습니다.');
        });
    }
    //추가
    job.jobAddBtn = function () {

        job.jobNM_data.resources = [{"langCd": "ko", "rspofcNm": ""}]
        job.job_nmgrid.refresh();

        return ocb.cmm.getLanguagesList(langCd);

    }
    //저장
    job.jobSaveBtn = function () {
        let param = {};
        let rspofcId = SBUxMethod.get('job_code');
        let langList = job.job_nmgrid.getGridDataAll();
        let sortSn = SBUxMethod.get('job_sortSn');
        let useYn = SBUxMethod.get('job_useYn');
        let rspofcNm = job.job_nmgrid.getCellData(1, 1);

        if (job.tabJsonData.id = '0') {
            param.gbCd = "JD";
        } else if (job.tabJsonData.id = '1') {
            param.gbCd = "JT";
        } else {
            param.gbCd = "JO";
        }

        if (!rspofcId) {
            alert('직위코드는 필수 입니다.');
            SBUxMethod.focus('job_code');
            return false;
        }

        let chkYn = false;

        langList.forEach(function (ele) {
            if (ele.rspofcNm != '') {
                chkYn = true;
            }
        });

        if (!chkYn) {
            alert('명칭은 필수 입니다.');

            return false;
        }

        if (!useYn) {
            alert('사용여부 선택은 필수 입니다.');
            SBUxMethod.focus('job_useYn');
            return false;
        }

        langList.forEach(function (ele) {
            ele.cmpnyId = d_cmpnyId;
            ele.rspofcId = rspofcId;
        })

        param.cmpnyId = d_cmpnyId;
        param.rspofcNm = rspofcNm;
        param.rspofcNms = langList;
        param.sortSn = sortSn;
        param.useYn = useYn;
        param.rspofcId = rspofcId;

        job.countJobTitle(param);
    }

    //count api
    job.countJobTitle = function (param) {
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/count', JSON.stringify(param), 'application/json', true, function (res) { // success callback
            if (res.code === 'OK') {
                if (res.data >= 1) {
                    alert('중복된 데이터가 존재합니다.');
                    return false;
                }
            }
            alert('중복된 데이터가 없습니다. 저장하시겠습니까?');
            job.addJobTitle(param);

        }, function (res) {
            console.log('res >>> ', res);
            ocb.cmm.errMsgHandler(res);
            alert('중복확인 실패하였습니다.');
        });
    }

    //add api
    job.addJobTitle = function (param) {
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/jobtitle/manage/info/add', JSON.stringify(param), 'application/json', true, function (res) { // success callback
            if (res.code === 'OK') {
                alert('저장 되었습니다.');
                job.jdDataGrid.refresh();
            }
        }, function (res) {
            console.log('res >>> ', res);
            ocb.cmm.errMsgHandler(res);

            alert('저장 실패하였습니다.');
        });
    }

    return job;

})
();
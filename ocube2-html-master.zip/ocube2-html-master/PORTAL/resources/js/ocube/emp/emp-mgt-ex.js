var empsMgt = (function () {
    let emps = {};


    emps.selConComTemp = [
        {
            text: "전체",
            value: "Y"
        },
        {
            text: "재직",
            value: "N"
        },
        {
            text: "퇴직",
            value: "S"
        }
    ]
    emps.selComStateTemp = [
        {
            text: "재직",
            value: "Y"
        },
        {
            text: "휴직",
            value: "N"
        },
        {
            text: "퇴직",
            value: "S"
        }
    ]
    emps.selOrgTemp = [
        {
            text: "표시",
            value: "Y"
        },
        {
            text: "미표시",
            value: "N"
        }
    ]
    emps.selComNmTemp = [
        {
            text: "회사이름1",
            value: "comNm"
        },
        {
            text: "회사이름2",
            value: "comNm2"
        }
    ]
    emps.selEmpTypeTemp = [
        {
            text: "전체",
            value: "Y"
        },
        {
            text: "정규직",
            value: "N"
        },
        {
            text: "계약직",
            value: "N"
        }
    ]
    emps.selJdTemp = [
        {
            text: "직위",
            value: "JD"
        }
    ]
    emps.selJtTemp = [
        {
            text: "직책",
            value: "JT"
        }
    ]
    emps.rdoSexCd = [
        {
            text: "여성",
            value: "F"
        },
        {
            text: "남성",
            value: "M"
        }
    ]
    emps.rdoOrgan = [
        {
            text: "표시",
            value: "Y"
        },
        {
            text: "미표시",
            value: "N"
        }
    ]
    emps.selJoTemp = [
        {
            text: "사무직",
            value: "Y"
        },
        {
            text: "생산직",
            value: "N"
        }
    ]
    emps.selMarriageTemp = [
        {
            text: "미혼",
            value: "Y"
        },
        {
            text: "기혼",
            value: "N"
        }
    ]
    emps.empsDataGrid;
    emps.empsProperties = {};
    emps.empsData = {
        resources: []
    }
    emps.empsJoinDataGrid;
    emps.empsJoinProperties = {};
    emps.empsJoinData = {
        resources: []
    }
    emps.empsAuthorityDataGrid;
    emps.empsAuthorityProperties = {};
    emps.empsAuthorityData = {
        resources: []
    }
    emps.empsAffiliationDataGrid;
    emps.empsAffiliationProperties = {};
    emps.empsAffiliationData = {
        resources: []
    }
    emps.empNameGrid;
    emps.empNameGridProperties = {};
    emps.empNamedata = {
        resources: []
    }

    emps.init = function (globalOpt) {
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        empsGrid();
    };

    let attachEvent = function (obj) {

    };

    let initDataLoad = function (obj) {

    };

    let empsGrid = function () {

        emps.empsProperties.parentid = 'emp_list';
        emps.empsProperties.id = 'empsMgt.empsDataGrid';
        emps.empsProperties.jsonref = 'empsMgt.empsData.resources';
        emps.empsProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        emps.empsProperties.columns = [

            //ref 연결필요
            {
                caption: [''],
                ref: 'D',
                width: '10%',
                style: 'text-align:center',
                type: 'checkbox',
                typeinfo: {
                    checkedvalue: 'T',
                    uncheckedvalue: 'F',
                    fixedcellcheckbox: {usemode: true, rowindex: 1, deletecaption: false}
                }
            },
            {caption: ['사원번호'], ref: 'A', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'B', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['ID'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['회사'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['직위'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['직책'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['고용형태'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['재직여부'], ref: 'C', width: '10%', style: 'text-align:center', type: 'output'}
        ]
        emps.empsDataGrid = _SBGrid.create(emps.empsProperties);

    };

    let empsJoinListCreateGrid = function () {

        emps.empsJoinProperties.parentid = 'empsJoin';
        emps.empsJoinProperties.id = 'empsMgt.empsJoinDataGrid';
        emps.empsJoinProperties.jsonref = 'empsMgt.empsJoinData.resources';
        emps.empsJoinProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        emps.empsJoinProperties.columns = [
            //ref 연결필요
            {caption: ['입사일'], ref: 'A', width: '33%', style: 'text-align:center', type: 'output'},
            {caption: ['퇴사일'], ref: 'S', width: '33%', style: 'text-align:center', type: 'output'},
            {caption: ['고용형태'], ref: 'B', width: '34%', style: 'text-align:center', type: 'output'}
        ]
        emps.empsJoinDataGrid = _SBGrid.create(emps.empsJoinProperties);

    };

    let empsAuthorityCreateGrid = function () {

        emps.empsAuthorityProperties.parentid = 'auth';
        emps.empsAuthorityProperties.id = 'empsMgt.empsAuthorityDataGrid';
        emps.empsAuthorityProperties.jsonref = 'empsMgt.empsAuthorityData.resources';
        emps.empsAuthorityProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        emps.empsAuthorityProperties.columns = [
            //ref 연결필요
            {caption: [''], ref: 'A', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['권한그룹명'], ref: 'A', width: '85%', style: 'text-align:center', type: 'output'}
        ]
        emps.empsAuthorityDataGrid = _SBGrid.create(emps.empsAuthorityProperties);

    };

    let empsAffiliationCreateGrid = function () {


        emps.empsAffiliationProperties.parentid = 'empsAffiliation';
        emps.empsAffiliationProperties.id = 'empsMgt.empsAffiliationDataGrid';
        emps.empsAffiliationProperties.jsonref = 'empsMgt.empsAffiliationData.resources';
        emps.empsAffiliationProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        emps.empsAffiliationProperties.columns = [
            //ref 연결필요
            {caption: ['주/부'], ref: 'E', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['회사'], ref: 'F', width: '20%', style: 'text-align:center', type: 'output'},
            {caption: ['주/부'], ref: 'G', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'H', width: '20%', style: 'text-align:center', type: 'output'},
            {caption: ['직위'], ref: 'I', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['직책'], ref: 'J', width: '15%', style: 'text-align:center', type: 'output'}
        ]
        emps.empsAffiliationDataGrid = _SBGrid.create(emps.empsAffiliationProperties);
    };

    let empsNameCreateGrid = function () {
        emps.empNameGridProperties.parentid = 'empsName';
        emps.empNameGridProperties.id = 'empsMgt.empNameGrid';
        emps.empNameGridProperties.jsonref = 'empsMgt.empNamedata.resources';
        emps.empNameGridProperties.emptyrecords = '데이터가 존재하지 않습니다.';
        emps.empNameGridProperties.columns = [
            //ref 연결필요
            {caption: ['이름'], ref: 'E', width: '50%', style: 'text-align:center', type: 'output'},
            {caption: ['명칭'], ref: 'F', width: '50%', style: 'text-align:center', type: 'output'}
        ]
        emps.empNameGrid = _SBGrid.create(emps.empNameGridProperties);

        emps.empNamedata.resources = [{"langCd": ["ko", "en"], "rspofcNm": ""}]
        return ocb.cmm.getLanguagesList(langCd);
    };

    emps.modalCallBack = function () {
        document.querySelector('#modal_emp').addEventListener("click", function (e) {
            SBUxMethod.closeModal('modal_emp')
        })
        document.querySelector('.sbux-mol-dlg').addEventListener("click", function (e) {
            e.stopPropagation()
        })
        empsJoinListCreateGrid();
        empsAuthorityCreateGrid();
        empsAffiliationCreateGrid();
        empsNameCreateGrid();
    }
    return emps;
})();
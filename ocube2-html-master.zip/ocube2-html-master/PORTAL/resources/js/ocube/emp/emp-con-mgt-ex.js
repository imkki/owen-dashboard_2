var empList = [];
var empConList = [];
let empInfo;
let G_msg;
let G_grp_id;
let G_cmpny_nm_list = [];
//let G_cmpny_id;
var empConMgt = (function(){
    let emp = {};

    /*겸직 회사 목록*/
    emp.cmpnyNmData = [];

    /*겸직회사 주/부 여부*/
    emp.cmpnyMainYnData = [];

    /*겸직부서 주/부 여부*/
    emp.deptMainYnData = [];

    /*재작상태코드*/
    emp.hffcStCdData = [];

    /*근태적용여부*/
    emp.dclzApplcYnData = [];

    /*직위*/
    emp.deptJdData = [];

    /*직책*/
    emp.deptJtData = [];

    /*부서목록*/
    emp.deptListData = [];

    /*사원목록*/
    emp.empListData = [];

    /*직종*/
    emp.jssfcIdData = [];

    /*고용형태*/
    emp.emplymStleCdData = [];

    emp.empDataGrid;
    emp.empProperties = {};
    emp.empData = {
        resources: []
    }
    emp.empDepartDataGrid;
    emp.empDepartProperties = {};
    emp.empDepartData = {
        resources: []
    }

    emp.init = function(globalOpt){
        var param ={};
        empInfo = ocb.cmm.getMyEmpInfo();

        G_msg = globalOpt.springMsg;
        G_grp_id = empInfo.grpId;
        G_cmpny_id = empInfo.cmpnyId;
        G_cmpny_nm_list = ocb.cmm.getCmpnyList(param).cmpnyList;

        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function(obj){
        createSelectBox();
        empCreateGrid();
        empListCreateGrid();
    };

    var createSelectBox = function() {

        var cmpny_nm = G_cmpny_nm_list;

        cmpny_nm.forEach(function(ele){
            ele.text =  ''+ ele.cmpnyNm;
            ele.value = ''+ ele.cmpnyId;
        });

        /*겸직 회사 목록*/
        emp.cmpnyNmData = cmpny_nm;

        /*겸직회사 주/부 여부*/
        emp.cmpnyMainYnData = [
            { text: G_msg.mainY, value: "Y" },
            { text: G_msg.mainN, value: "N" }];

        /*겸직부서 주/부 여부*/
        emp.deptMainYnData = [
            { text: G_msg.mainY, value: "Y" },
            { text: G_msg.mainN, value: "N" }];

        /*재직상태코드*/
        emp.hffcStCdData = [
            { text : G_msg.workY, value : "100"},
            { text : G_msg.workN, value : "900"}];

        /*근태적용여부*/
        emp.dclzApplcYnData = [
            { text : G_msg.applyY, value : "Y"},
            { text : G_msg.applyN, value : "N" }];

        /*직종*/
        emp.jssfcIdData = [
            { text : "사무직", value : "Y"},
            { text : "현장직", value : "N"}
        ];

        /*고용형태*/
        emp.emplymStleCdData = [
            { text : "정규직", value : "Y"},
            { text : "계약직", value : "N"}
        ];

        SBUxMethod.refresh('cmpnyNm');
        SBUxMethod.refresh('cmpnyMainYn');
        SBUxMethod.refresh('deptMainYn');
        SBUxMethod.refresh('hffcStCd');
        SBUxMethod.refresh('dclzApplcYn');
        SBUxMethod.refresh('jssfcId');
        SBUxMethod.refresh('emplymStleCd');
    }

    let attachEvent = function(obj){
        emp.empDataGrid.bind('click', empGridRowClick);
        emp.empDepartDataGrid.bind('click', empDartGridRowClick);
    };

    let initDataLoad = function(obj){
        var param = {};
        getEmpList(param);
    };

    emp.addSubDuty = function(){

        let nRow = emp.empDataGrid.getRow();
        let param = emp.empDataGrid.getRowData(nRow,true);

        if (!param) {
            alert("겸직 정보를 추가할 직원을 먼저 선택해주세요.");
            return;
        }

        param.type = "NEW";
        setSubDuty(param);
    }

    emp.empSearch = function() {
        var param = {};
        param.empNm = SBUxMethod.get('empNm');
        getEmpList(param);
    }

    emp.setDeptJdJt = function(obj) {
        //console.log("cmpnyNm ? ", obj);
        var param = {};
        param.cmpnyId = obj;
        var jobTitles = ocb.cmm.getJobTitle(param);
        //console.log("setDeptJdJt jobTitles ? ", jobTitles);

        jobTitles.jtTxtData.forEach(function(ele){
            ele.text = '' + ele.rspofcNm;
            ele.value = '' + ele.rspfcId;
        });

        jobTitles.jdTxtData.forEach(function (ele){
            ele.text = '' + ele.rspofcNm;
            ele.value = '' + ele.rspfcId;
        });

        /*직책*/
        emp.deptJtData = jobTitles.jtTxtData;
        /*직위*/
        emp.deptJdData = jobTitles.jdTxtData;

        let nRow = _SBGrid.getGrid('empConMgt.empDataGrid').getRow();
        let empInfo = _SBGrid.getGrid('empConMgt.empDataGrid').getRowData(nRow,true);
        //console.log("empInfo ? ", empInfo);
        param.empId = empInfo.empId;
        var deptInfo = ocb.cmm.getDeptList(param);
        /*부서목록*/
        emp.deptListData = deptInfo.deptList;
        //console.log("G_cmpny_nm_list ? ", G_cmpny_nm_list);
        param.grpId = empInfo.grpId;
        /*회사재직정보*/
        var subInfo = ocb.cmm.getEmpInfo(param);
        //console.log("subInfo ? ", subInfo.empInfo);
        if (!subInfo) {
            if (subInfo.empInfo.empNoc) {
                SBUxMethod.set('empId', subInfo.empInfo.empNoc);
            }

            if (subInfo.empInfo.hffcStCd) {
                SBUxMethod.set('hffcStCd', subInfo.empInfo.hffcStCd);
            }

            if (subInfo.empInfo.dclzApplcYn) {
                SBUxMethod.set('dclzApplcYn', subInfo.empInfo.dclzApplcYn);
            }

        }

        SBUxMethod.refresh('deptJd');
        SBUxMethod.refresh('deptJt');
        SBUxMethod.refresh('deptNm');
    }

    emp.saveSubDutyInfo = function() {

        let nRow = _SBGrid.getGrid('empConMgt.empDataGrid').getRow();
        let empInfo = _SBGrid.getGrid('empConMgt.empDataGrid').getRowData(nRow,true);

        //console.log("emp ? ", emp);

        let dutyRow = _SBGrid.getGrid('empConMgt.empDepartDataGrid').getRow();
        let dutyInfo = _SBGrid.getGrid('empConMgt.empDepartDataGrid').getRowData(dutyRow,true);

        //console.log("emp2 ? ", emp2);

        var param = {};
        param.deptMapInfo = {};
        param.cmpnyMapInfo = {};
        param.deptMapInfo.cmpnyId = empInfo.cmpnyId;                    /*회사ID*/
        param.deptMapInfo.empId = empInfo.empId;                        /*사원ID*/
        param.deptMapInfo.mainYn = SBUxMethod.get("deptMainYn");       /*메인여부*/
        param.deptMapInfo.rspofcId = SBUxMethod.get("deptJd");
        param.deptMapInfo.originMainYn = "N";
        param.deptMapInfo.dspYn = "N";
        param.deptMapInfo.sortSn = "1000";

        param.cmpnyMapInfo.cmpnyId = empInfo.cmpnyId;
        param.cmpnyMapInfo.empId = empInfo.empId;
        param.cmpnyMapInfo.originMainYn = "N";
        param.cmpnyMapInfo.mainYn = SBUxMethod.get("deptMainYn");
        param.cmpnyMapInfo.jssfcId = SBUxMethod.get("jssfcId");           /*직종ID*/
        param.cmpnyMapInfo.clsfId = SBUxMethod.get("deptJt");
        param.cmpnyMapInfo.hffcStCd = SBUxMethod.get("hffcStCd");         /*재직상태코드*/
        param.cmpnyMapInfo.ecnyDd = SBUxMethod.get("ecnyDd");             /*입사일자*/
        param.cmpnyMapInfo.retireDd = SBUxMethod.get("retireDd");         /*퇴사일자*/
        param.cmpnyMapInfo.dclzApplcYn = SBUxMethod.get("dclzApplcYn");   /*고용형태코드*/
        param.cmpnyMapInfo.delYn = "N";


        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/emp/concurrent/info/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                if (retObj) {
                    alert("저장했습니다.");
                }
            } else {
                alert('겸직 정보 저장하는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }

    emp.removeSubDutyInfo = function() {

        let nRow = _SBGrid.getGrid('empConMgt.empDataGrid').getRow();
        let empInfo = _SBGrid.getGrid('empConMgt.empDataGrid').getRowData(nRow,true);
        //console.log("checked ? ", _SBGrid.getGrid('empConMgt.empDepartDataGrid').getCheckedRowData(0));
        var list = _SBGrid.getGrid('empConMgt.empDepartDataGrid').getCheckedRowData(0);

        if (list.length === 0) {
            alert('삭제할 겸직 정보를 선택해주세요.');
            return;
        }

        var param = {};
        param.deptList = [];

        for (var i=0; i<list.length; i++) {
            param.deptList.push({"cmpnyId" : list[i].data.cmpnyId, "deptId" : list[i].data.deptId, "empId" : empInfo.empId});
        }

        //console.log("param ? ", param);

        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/emp/concurrent/info/remove', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                if (retObj) {
                    alert("삭제했습니다.");
                }
            } else {
                alert('겸직 정보 삭제하는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }


    var empGridRowClick = function(){

        let nRow = emp.empDataGrid.getRow();
        let param = emp.empDataGrid.getRowData(nRow,true);
        //console.log("param > ", param);
        if (param) {
            getEmpConList(param);
        }
        param.type = "NEW";
        setSubDuty(param);
    }

    var empDartGridRowClick = function() {

        let nRow = emp.empDepartDataGrid.getRow();
        let param = emp.empDepartDataGrid.getRowData(nRow,true);

        if (param) {
            param.type = "EDIT";
            setSubDuty(param);
        }
    }

    var setSubDuty = function(param) {
        console.log("setSubDuty param ? ", param);
        $("#subDutyDiv").css("display", "block");

        var jobTitles = ocb.cmm.getJobTitle(param);
        if (param.type === "EDIT") {

            emp.deptJdData = jobTitles.jdTxtData;
            emp.deptJtData = jobTitles.jtTxtData;
            SBUxMethod.set("cmpnyMainYn",param.cmpnyMainYn);
            SBUxMethod.set("cmpnyNm",param.cmpnyId);
            SBUxMethod.set("deptMainYn",param.deptMainYn);
            SBUxMethod.set("deptNm",param.deptNm);
            SBUxMethod.refresh('deptJd');
            SBUxMethod.refresh('deptJt');
            SBUxMethod.set("deptJd", param.clsfNm);
            SBUxMethod.set("deptJt", param.rspofcNm);
            SBUxMethod.set("hffcStCd",param.hffcStCd);
            SBUxMethod.set("dclzApplcYn",param.dclzApplcYn);

        } else {
            SBUxMethod.set("cmpnyMainYn","N");
            SBUxMethod.set("cmpnyNm","");
            SBUxMethod.set("deptMainYn","N");
            SBUxMethod.set("deptNm","");
            SBUxMethod.set("deptJd", "");
            SBUxMethod.set("deptJt","");
        }
    }

    let empCreateGrid = function () {
        var paging = { 'type' : 'page', 'count' : 5, 'size' : 10, 'sorttype' : 'all', 'showgoalpageui' : true };	// 페이징 처리
        emp.empDataGrid = sbuxComponent.makeGrid(emp.empDataGrid , emp.empProperties, 'emp_left_list', 'empConMgt.empDataGrid','empConMgt.empData.resources', '데이터가 존재하지 않습니다.', empColumns(), paging);
        emp.empDataGrid.bind("beforepagechanged", gridPagingClick);
        emp.empDataGrid.bind("afterpagechanged", "appendGridPageUI");
        emp.empDataGrid.bind("afterrefresh", "appendGridPageUI");
        emp.empDataGrid.bind("afterrebuild", "appendGridPageUI");
    };
    let empListCreateGrid = function () {

        emp.empDepartDataGrid  = sbuxComponent.makeGrid(emp.empDepartDataGrid , emp.empDepartProperties, 'emp_right_list', 'empConMgt.empDepartDataGrid','empConMgt.empDepartData.resources', '데이터가 존재하지 않습니다.', empDepartColumns());

    };

    let gridPagingClick = function (){
        var param = {};
        getEmpList(param);
    }

    var getEmpList = function(param) {
        param = ocb.cmm.getGridPagingParam(emp.empDataGrid);
        //console.log("ocb.cmm.getGridPagingParam(emp.empDataGrid) ? ", param);
        param.cmpnyId = empInfo.cmpnyId;
        param.grpId = empInfo.grpId;
        param.cmpnyMainYn = 'Y';
        param.deptMainYn = 'Y';
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/emp/manage/page/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;

                if (retObj) {
                    let totalCnt = retObj.totalCnt;
                    empList = retObj ? retObj.list:[];
                    empList.forEach(function(ele){
                        ele.empId = ''+ ele.empId;
                        ele.empNm = ele.empNm ? ''+ ele.empNm:'';
                        ele.loginId = ele.loginId ? ele.loginId:'';
                        ele.label = ele.empNm ? ''+ ele.empNm:'';
                        ele.value = ele.empId ?''+ ele.empId:'';
                    })

                    emp.empListData = empList;
                    emp.empData.resources = empList;
                    emp.empDataGrid.setPageTotalCount(totalCnt);
                    emp.empDataGrid.refresh();
                    SBUxMethod.refresh('empNm');
                }
            } else {
                alert('사원 정보를 불러오는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }

    var getEmpConList = function(param) {
        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/emp/concurrent/detail/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
            if( res.code === 'OK' ){
                let retObj = res.data;
                //console.log("retObj ? ", retObj);
                if (retObj) {
                    empConList = retObj ? retObj:[];
                    //console.log("empConList ? ", empConList);
                    empConList.forEach(function(ele){
                        ele.clsfId = ele.clsfId+'';
                        ele.cmpnyId = ele.cmpnyId+'';
                        ele.cmpnyMainYn = ele.cmpnyMainYn+'';
                        ele.cmpnyNm = ele.cmpnyNm+'';
                        ele.cmpnyNmAbrv = ele.cmpnyNmAbrv+'';
                        ele.deptId = ele.deptId+'';
                        ele.deptMainYn = ele.deptMainYn+'';
                        ele.deptNm = ele.deptNm+'';
                        ele.empId = ele.empId+'';
                        ele.empNm = ele.empNm+'';
                        ele.grpId = ele.grpId+'';
                        ele.grpNm = ele.grpNm+'';
                        ele.hffcStCd = ele.hffcStCd+'';
                        ele.loginId = ele.loginId+'';
                        ele.rspofcId = ele.rspofcId+'';
                        ele.rspofcNm = ele.rspofcNm+'';
                        ele.clsfId = ele.clsfId+'';
                        ele.clsfNm = ele.clsfNm+'';
                        ele.sortSn = ele.sortSn ? ele.sortSn : 0;
                        ele.upperDeptId = ele.upperDeptId+'';
                    })
                    empConMgt.empDepartData.resources = empConList;
                    emp.empDepartDataGrid.refresh();
                }
            } else {
                alert('겸직 정보를 조회하는데 실패하였습니다.');
            }
        }, function(res){
            alert(res.message);
        });
    }

    var empColumns = function() {
        return [
            {
                caption: ['사원번호']
                , ref: 'empId'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            },
            {
                caption: ['이름']
                , ref: 'empNm'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            },
            {
                caption: ['ID']
                , ref: 'loginId'
                , width: '34%'
                , style: 'text-align:center'
                , type: 'output'
            }]
    }

    var empDepartColumns = function() {
        return [
            //ref 연결필요
            {
                caption: [''],
                ref: 'D',
                width: '17.5%',
                style: 'text-align:center',
                type: 'checkbox'
            },
            {
                caption: ['회사구분']
                , ref: 'cmpnyMainYn'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
                , format : {
                    type :'custom'
                    , callback : function (cmpnyMainYn){
                        return ocb.cmm.getMainNm(G_msg, cmpnyMainYn);
                    }
                }
            },
            {
                caption: ['회사']
                , ref: 'cmpnyNm'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            },
            {
                caption: ['부서구분']
                , ref: 'deptMainYn'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
                , format : {
                    type :'custom'
                    , callback : function (deptMainYn){
                        return ocb.cmm.getMainNm(G_msg, deptMainYn);
                    }
                }
            },
            {
                caption: ['부서명']
                , ref: 'deptNm'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            },
            {
                caption: ['직위']
                , ref: 'rspofcNm'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            },
            {
                caption: ['직책']
                , ref: 'C'
                , width: '33%'
                , style: 'text-align:center'
                , type: 'output'
            }
        ]
    }

    return emp;
})();
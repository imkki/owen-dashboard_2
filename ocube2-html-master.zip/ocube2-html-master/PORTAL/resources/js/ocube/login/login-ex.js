var lgEx = (function () {
    let z = {};

    // messsage
    // TODO 다국어 메시지

    let pwRuleMessage1 = "숫자가 포함되지 않았습니다.";
    let pwRuleMessage2 = "영문이 포함되지 않았습니다.";
    let pwRuleMessage3 = "소문자가 포함되지 않았습니다.";
    let pwRuleMessage4 = "대문자가 포함되지 않았습니다.";
    let pwRuleMessage5 = "동일 문자를 연속 4번 이상 사용하실 수 없습니다.";

    /*let alertMsgUnknownErr = '프로그램에 오류가 있습니다. 새로고침 후에 다시 시도해 주세요';
    let alertMsgCodeRequired = '코드를 입력해 주세요';
    let alertMsgUseYnSelect = '사용여부를 선택해 주세요';
    let alertMsgCodeNameRequired = '명칭을 입력해 주세요';
    let alertMsgCodeNameKoRequired = '한글 명칭은 필수 입력항목 입니다';
    let alertMsgSortOdrOnlyNumber = '정렬 순번을 숫자로만 입력해 주세요';
    let alertMsgExistLowerCd = '하위코드가 존재하여 삭제할 수 없습니다.';
    let confirmMsgRegTitle = '등록';
    let confirmMsgUpdTitle = '수정';
    let confirmMsgDelTitle = '삭제';
    let confirmMsgAsking = '하시겠습니까?';
    let processedMsgOk = '처리 되었습니다';
    let gridHeaderNameText = '코드명';
    let gridHeaderCodeText = '코드';
    let gridHeaderUseYnText = '사용여부';*/


    z.init = function (params) {
        /*if (params) {
            alertMsgUnknownErr = params.alertMsgUnknownErr;
            alertMsgCodeRequired = params.alertMsgCodeRequired;
            alertMsgUseYnSelect = params.alertMsgUseYnSelect;
            alertMsgCodeNameRequired = params.alertMsgCodeNameRequired;
            alertMsgCodeNameKoRequired = params.alertMsgCodeNameKoRequired;
            alertMsgSortOdrOnlyNumber = params.alertMsgSortOdrOnlyNumber;
            alertMsgExistLowerCd = params.alertMsgExistLowerCd;
            confirmMsgRegTitle = params.confirmMsgRegTitle;
            confirmMsgUpdTitle = params.confirmMsgUpdTitle;
            confirmMsgDelTitle = params.confirmMsgDelTitle;
            confirmMsgAsking = params.confirmMsgAsking;
            processedMsgOk = params.processedMsgOk;
            gridHeaderNameText = params.gridHeaderNameText;
            gridHeaderCodeText = params.gridHeaderCodeText;
            gridHeaderUseYnText = params.gridHeaderUseYnText;
        }*/
    }

    z.fnRestLoginAction2 = function () {
        //let loginFailCnt = 0;	// 로그인 실패 횟수 (임시)
        //let err = undefined;

        let id = z.getSbId();
        let pwd = z.getSbVal("input_pw");


        if (id === '') {
            alert('아이디가 입력되지 않았습니다.');
            return false;
        }
        if (pwd === '') {
            alert('비밀번호가 입력되지 않았습니다.');
            return false;
        }

        z.retrieveLoginToken(function (res) {
            let tokenObj = res.data;
            //printTrace(">>> retrive token=> ", tokenObj)
            //printTrace(">>> retrive token0=> ", tokenObj.token0)
            //printTrace(">>> retrive token1=> ", tokenObj.token1)
            if (typeof tokenObj === 'undefined') {
                alert('로그인 수행에 필요한 정보를 가져오지 못했습니다. 새로고침후에 재 시도 해주세요.');
                return false;
            }

            let reqParams = {};
            reqParams.params = z.encryptMainLogin(id, pwd, tokenObj.token0, tokenObj.token1);
            reqParams.param0 = tokenObj.token0;

            loginExchangeAsync('POST', page_context_path + '/gsec/login/loginproc', 'application/x-www-form-urlencoded', reqParams, function (res) {
                printTrace("# [로그인 성공] res => ", res);
                location.href = page_context_path;
            }, function (res) {
                printTrace("# [로그인 실패] res => ", res);

                SBUxMethod.set("input_pw", '');
                $('#pwInfo').css('visibility', 'visible');

                const err = res;
                let err_html = err.message + "[" + err.code + "]";

                switch (err.code) {
                    case("LGN.ERR_1001.400"):
                    //잘못된계정,비번
                    case("LGN.ERR_1005.400"):
                        //미등록 IP 대역
                        err_html += "<br>확인 후, 다시 시도해주십시오.";
                        $('#fail_err_text').html(err_html);
                        SBUxMethod.openModal("modal_login_fail");
                        break;

                    case("LGN.ERR_1003.400"):
                        //계정잠김
                        err_html += "<br>사이트 관리자에게 문의하십시오.";
                        $('#ban_err_text').html(err_html);
                        SBUxMethod.openModal("modal_login_ban");
                        break;

                    case("LGN.ERR_1004.400"):
                        //패스워드만료
                        err_html += "<br>사이트 관리자에게 문의하십시오.";
                        $('#ban_err_text').html(err_html);
                        SBUxMethod.openModal("modal_pw_expired");
                        break;

                    case("LGN.ERR_1006.400"):
                        //패스워드 재설정 필요.
                        err_html += "<br>사이트 관리자에게 문의하십시오.";
                        $('#ban_err_text').html(err_html);
                        SBUxMethod.openModal("modal_pw_init");
                        break;
                }

                return false;
            });
        });
    }

    z.clearIdInfo = function () {
        let id = z.getSbId();
        if (id === '') {
            $('#idInfo').css('visibility', 'visible');
        } else {
            $('#idInfo').css('visibility', 'hidden');
        }
    }

    z.clearPwInfo = function () {
        let pwd = z.getSbVal("input_pw");
        if (pwd === '') {
            $('#pwInfo').css('visibility', 'visible');
        } else {
            $('#pwInfo').css('visibility', 'hidden');
        }
    }

    z.fnIdKeyUp = function () {
        z.clearIdInfo();
    }

    z.fnPwKeyUp = function () {
        z.clearPwInfo();
    }

    z.fnIdBlur = function () {
        z.clearIdInfo();
    }

    z.fnPwBlur = function () {
        z.clearPwInfo();
    }

    /*z.fnModalPwKeyUp = function () {
        let mpwd = z.getSbVal("input_new_pw");

        if (!z.checkPwRule(mpwd)) {
            $('#mpwInfo').css('visibility', 'visible');
        } else {
            $('#mpwInfo').css('visibility', 'hidden');
        }
    }*/

    // 초기화 요청
    z.requestLoginInit = function () {
        let id = z.getSbId();
        let name = z.getSbVal("input_init_name");

        if (id === '') {
            alert('아이디가 입력되지 않았습니다.');
            return false;
        }
        if (name === '') {
            alert('이름이 입력되지 않았습니다.');
            return false;
        }

        let params = {};
        params.loginId = id;
        params.empNm = name;

        if (confirm("초기화 요청을 하시겠습니까?")) {

            ocb.restcli.exchangeAsync('POST',
                page_context_path + '/rest/system/public/login/init/request',
                JSON.stringify(params),
                'application/json',
                true,
                function (res) {
                    if (res.code === 'OK') {
                        alert("관리자에게 초기화를 요청하였습니다.");
                    } else {
                        ocb.cmm.errMsgHandler(res);
                    }
                },
                function (res) {
                    alert("[" + res.code + "] " + res.message);
                    return false;
                });

            //alert('초기화 요청하였습니다.');
            SBUxMethod.set("input_init_id", '');
            SBUxMethod.set("input_init_name", '');
            SBUxMethod.closeModal('modal_init_request'); // modal close
        }
    }

    z.initPwByUser = function () {

        let currPwId = "init_curr_pw";
        let newPwId = "init_new_pw";
        let confirmPwId = "init_new_pw_confirm";
        let url = '/rest/system/public/login/pw/change';
        let modalId = "modal_pw_init";

        z.initPwCore(currPwId, newPwId, confirmPwId, modalId, url);
    }

    z.initExpiredPwByUser = function () {

        let currPwId = "exp_curr_pw";
        let newPwId = "exp_new_pw";
        let confirmPwId = "exp_new_pw_confirm";
        let url = '/rest/system/public/login/pw/change';
        let modalId = "modal_pw_expired";

        z.initPwCore(currPwId, newPwId, confirmPwId, modalId, url);
    }

    z.initPwCore = function (currPwId, newPwId, confirmPwId, modalId, url) {

        let id = z.getSbId();
        if (ocb.cmm.isNull(id)) {
            alert("id를 입력해주세요.")
            return;
        }

        let currPw = z.getSbVal(currPwId);
        let newPw = z.getSbVal(newPwId);

        if (!z.checkPw(currPwId, newPwId, confirmPwId)) return;

        let paramObj = {};
        paramObj.loginId = id;
        paramObj.loginPwd = currPw;
        paramObj.loginPwdNew = newPw;

        if (confirm("비밀번호를 변경하시겠습니까?")) {
            z.retrieveLoginToken(function (res) {
                let tokenObj = res.data;
                //printTrace(">>> retrive token=> ", tokenObj)
                //printTrace(">>> retrive token0=> ", tokenObj.token0)
                //printTrace(">>> retrive token1=> ", tokenObj.token1)
                if (typeof tokenObj === 'undefined') {
                    alert('로그인 수행에 필요한 정보를 가져오지 못했습니다. 새로고침후에 재 시도 해주세요.');
                    return false;
                }

                let params = {};
                params.params = z.encrypt(paramObj, tokenObj.token0, tokenObj.token1);
                params.param0 = tokenObj.token0;

                ocb.restcli.exchangeAsync('POST',
                    page_context_path + url,
                    JSON.stringify(params),
                    'application/json',
                    true,
                    function (res) {
                        if (res.code === 'OK') {
                            alert("계정 정보가 변경 되었습니다. 다시 로그인해주십시요.");
                        } else {
                            ocb.cmm.errMsgHandler(res);
                        }
                    },
                    function (res) {
                        alert("[" + res.code + "] " + res.message);
                        return false;
                    });
            });
        }
        SBUxMethod.closeModal(modalId);
    }

    z.keepGoingExpiredPw = function () {
        let id = z.getSbId();
        if (ocb.cmm.isNull(id)) {
            alert("id가 없습니다.")
            return;
        }

        const pw = z.getSbVal('input_pw');

        let paramObj = {};
        paramObj.loginId = id;
        paramObj.loginPwd = pw;
        paramObj.password = pw;

        if (confirm("현재비밀번호를 유지하시겠습니까?")) {

            z.retrieveLoginToken(function (res) {
                let tokenObj = res.data;

                if (typeof tokenObj === 'undefined') {
                    alert('로그인 수행에 필요한 정보를 가져오지 못했습니다. 새로고침후에 재 시도 해주세요.');
                    return false;
                }

                let params = {};
                params.params = z.encrypt(paramObj, tokenObj.token0, tokenObj.token1);
                params.param0 = tokenObj.token0;

                ocb.restcli.exchangeAsync('POST',
                    page_context_path + '/rest/system/public/login/expired/keepgoing',
                    JSON.stringify(params),
                    'application/json',
                    true,
                    function (res) {
                        if (res.code === 'OK') {
                            //location.href = page_context_path;
                            //alert("계정 정보가 변경 되었습니다. 다시 로그인해주십시요.");
                            loginExchangeAsync('POST', page_context_path + '/gsec/login/loginproc', 'application/x-www-form-urlencoded', params, function (res) {
                                printTrace("# [로그인 성공] res => ", res);
                                location.href = page_context_path;
                            }, function (res) {
                                printTrace("# [로그인 실패] res => ", res);
                                alert("로그인시 문제가 발생하였습니다.")
                            });
                        } else {
                            ocb.cmm.errMsgHandler(res);
                        }
                    },
                    function (res) {
                        alert("[" + res.code + "] " + res.message);
                        return false;
                    });
            });
        }
        SBUxMethod.closeModal('modal_pw_expired');
    }

    z.checkPw = function (currPwId, newPwId, confirmPwId) {
        let currPw = z.getSbVal(currPwId);
        let newPw = z.getSbVal(newPwId);
        let confirmPw = z.getSbVal(confirmPwId);

        if (currPw === '') {
            alert('현재 비밀번호를 입력해 주세요.');
            SBUxMethod.focus(currPwId);
            return false;
        }
        if (newPw === '') {
            alert('새로운 비밀번호를 입력해 주세요.');
            SBUxMethod.focus(newPwId);
            return false;
        }
        if (confirmPw === '') {
            alert('새로운 비밀번호(재입력)를 입력해 주세요.');
            SBUxMethod.focus(confirmPwId);
            return false;
        }

        /*if (initPw !== currPw) {
            alert('비밀번호가 올바르지 않습니다.');
            SBUxMethod.set('input_curr_pw', '');
            SBUxMethod.focus('input_curr_pw');
            return false;
        }*/

        if (newPw !== confirmPw) {
            //SBUxMethod.set('input_new_pw', '');
            //SBUxMethod.set('input_new_chk_pw', '');
            SBUxMethod.focus(newPwId);
            alert('비밀번호가 동일하지 않습니다.');
            return false;
        }

        if (currPw === newPw) {
            //SBUxMethod.set('input_new_pw', '');
            //SBUxMethod.set('input_new_chk_pw', '');
            SBUxMethod.focus(newPwId);
            $('#mpwInfo').css('visibility', 'visible');
            alert('현재 비밀번호와 동일합니다. 새로운 비밀번호를 입력해 주세요.');
            return false;
        }

        if (!z.checkPwRule(newPw)) {
            /*SBUxMethod.set('input_new_pw', '');
            SBUxMethod.set('input_new_chk_pw', '');*/
            SBUxMethod.focus(newPwId);
            $('#mpwInfo').css('visibility', 'visible');
            return false;
        }

        return true;
    }

    z.checkPwRule = function (pw) {
        const reg = z.makeRuleRegExp();
        const min = reg.min;
        const max = reg.max;
        const rgEx = reg.rgEx;

        //TODO 위치이동
        let pwRuleMessage0 = "숫자와 영문 대/소문자 조합으로 " + min + '~' + max + '자리만 가능합니다.';

        let isContainNumber = pw.search(/[0-9]/g) >= 0;
        let isContainLetter = pw.search(/[a-z]/ig) >= 0;
        let isContainLowerCase = pw.search(/[a-z]/g) >= 0;
        let isContainUpperCase = pw.search(/[A-Z]/g) >= 0;
        let isContainSerialLetter = /(\w)\1\1\1/.test(pw);

        if (!rgEx.test(pw)) {
            alert(pwRuleMessage0);
            return false;
        }

        if (!isContainNumber) {
            alert(pwRuleMessage1);
            return false;
        }

        if (!isContainLetter) {
            alert(pwRuleMessage2);
            return false;
        }

        if (!isContainLowerCase) {
            alert(pwRuleMessage3);
            return false;
        }

        if (!isContainUpperCase) {
            alert(pwRuleMessage4);
            return false;
        }

        if (isContainSerialLetter) {
            alert(pwRuleMessage5);
            return false;
        }

        return true;
    }

    z.makeRuleRegExp = function () {
        // TODO min/max get from DB
        let result = {};
        result.min = 3;
        result.max = 20;
        const rgExStr = "^[a-zA-Z0-9!@#$%^&*()?_~]{" + result.min + "," + result.max + "}$";
        result.rgEx = new RegExp(rgExStr);
        return result;
    }

    z.encrypt = function (param, pkey, piv) {
        let akey = CryptoJS.enc.Hex.parse(pkey);
        let aiv = CryptoJS.enc.Hex.parse(piv);

        let encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(param)), akey, {
            iv: aiv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        });

        let encryptedTxt = 'oc' + encrypted.toString() + 'la';
        encryptedTxt = encodeURIComponent(encryptedTxt);
        return encryptedTxt;
    }

    z.encryptMainLogin = function (id, pw, pkey, piv) {
        let paramObj = {};
        paramObj.loginId = id;
        paramObj.password = pw;

        return z.encrypt(paramObj, pkey, piv);
    }

    z.retrieveLoginToken = function (fnCallback) {
        let rurl = page_context_path + '/rest/system/public/issuance/ltoken/get';
        ocb.restcli.exchangeAsync('POST', rurl, {}, 'application/x-www-form-urlencoded', true, fnCallback, function (res) {
            alert('토근정보를 가져올 수 없습니다. 로그인에 실패 하였습니다.\r\n [' + res.code + '] ' + res.message);
            return false;
        });
    }

    /**
     *
     * @param id ex) "input_pw"
     * @returns {string|string}
     */
    z.getSbVal = function (id) {
        return SBUxMethod.get(id) ? SBUxMethod.get(id).trim() : '';
    }

    z.getSbId = function () {
        return z.getSbVal("input_id").toLowerCase();
    }

    z.openInitModal = function () {
        SBUxMethod.openModal('modal_init_request');
        SBUxMethod.closeModal('modal_login_ban');
    }

    function loginExchangeAsync(method, url, contentType, data, sucCallback, errCallback) {
        const opt = {
            type: method,
            url: url,
            datatype: 'json',
            contentType: contentType,
            data: data,
            async: true,
            success: function (res) {
                console.log(" res :: ", res)
                let response = res.result;

                if (response !== undefined && response.code === 'OK') {
                    if (typeof sucCallback === 'function') {
                        sucCallback.call(this, response);
                    }
                } else {
                    if (typeof errCallback === 'function') {
                        errCallback.call(this, res);
                    }
                }
            },
            error: function (e) {
                try {
                    printTrace('error >>', JSON.stringify(e));
                } catch (_e) {
                    printTrace('error >>', JSON.stringify(e));
                }
                // ows.cmm.errorHandle(res);
                if (typeof errCallback === 'function') {
                    errCallback.call(this, e);
                }
            }
        };
        $.ajax(opt);
    }

    return z;
})();
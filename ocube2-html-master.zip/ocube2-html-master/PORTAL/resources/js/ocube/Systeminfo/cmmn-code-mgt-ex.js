var cmmCdMgtEx = (function(){
	let o = {};

	o.dataGridId;
	o.gridProps = {};
	o.gridDataList = [];
	let isEventBinded = false;
	let langCodeNameList = [];

	let alertMsgUnknownErr = '프로그램에 오류가 있습니다. 새로고침 후에 다시 시도해 주세요';
	let alertMsgCodeRequired = '코드를 입력해 주세요';
	let alertMsgUseYnSelect = '사용여부를 선택해 주세요';
	let alertMsgCodeNameRequired = '명칭을 입력해 주세요';
	let alertMsgCodeNameKoRequired = '한글 명칭은 필수 입력항목 입니다';
	let alertMsgSortOdrOnlyNumber = '정렬 순번을 숫자로만 입력해 주세요';
	let alertMsgExistLowerCd = '하위코드가 존재하여 삭제할 수 없습니다.';
	let confirmMsgRegTitle = '등록';
	let confirmMsgUpdTitle = '수정';
	let confirmMsgDelTitle = '삭제';
	let confirmMsgAsking = '하시겠습니까?';
	let processedMsgOk = '처리 되었습니다';
	let gridHeaderNameText = '코드명';
	let gridHeaderCodeText = '코드';
	let gridHeaderUseYnText = '사용여부';


	o.init = function(globalOpt){
		if(globalOpt) {
			alertMsgUnknownErr = globalOpt.alertMsgUnknownErr;
			alertMsgCodeRequired = globalOpt.alertMsgCodeRequired;
			alertMsgUseYnSelect = globalOpt.alertMsgUseYnSelect;
			alertMsgCodeNameRequired = globalOpt.alertMsgCodeNameRequired;
			alertMsgCodeNameKoRequired = globalOpt.alertMsgCodeNameKoRequired;
			alertMsgSortOdrOnlyNumber = globalOpt.alertMsgSortOdrOnlyNumber;
			alertMsgExistLowerCd = globalOpt.alertMsgExistLowerCd;
			confirmMsgRegTitle = globalOpt.confirmMsgRegTitle;
			confirmMsgUpdTitle = globalOpt.confirmMsgUpdTitle;
			confirmMsgDelTitle = globalOpt.confirmMsgDelTitle;
			confirmMsgAsking = globalOpt.confirmMsgAsking;
			processedMsgOk = globalOpt.processedMsgOk;
			gridHeaderNameText = globalOpt.gridHeaderNameText;
			gridHeaderCodeText = globalOpt.gridHeaderCodeText;
			gridHeaderUseYnText = globalOpt.gridHeaderUseYnText;
		}
		render(function(){loadInitData();});
	};

	o.refresh = function(){
		render(function(){loadInitData();});
	}

	o.gridClick = function(){
		if(!o.dataGridId) return;
		bindFormData( o.dataGridId.getRowData(o.dataGridId.getRow(),false) );
	}

	o.gridDblclick = function(){

	}

	function errAlert(s){
		console.log('[a]Error:', s);
	}
	let render = function(fncallback){
		let taskPromis = new Promise(function(resolve, reject) {
			console.log('11111111111111');
			createGrid(resolve());
		}).then(function(){
			bindEvent();
		}).then(function() {
			return new Promise(function(resolve, reject) {
				loadLangCodeNames(resolve, reject);
			})
		}).then(function(){
			loadGridData();
			console.log('222222222222222');
		}).then(function(){
			console.log('333333333333333');
		}).finally(function() {
			console.log('444444444 finally 444444444');
		});
		//createGrid();
		//bindEvent();


		SBUxMethod.attr('btn_del','disabled','true');
	};

	let loadLangCodeNames = function(sucCalback, errCallback){
		let params = {upperCd:'env.lang'};
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmn/cmmncode/list', JSON.stringify(params), 'application/json', true,
			function (res) {
				if (res.code === 'OK') {
					renderLangCodeNames(res.data);
					console.log('222222222 loadLangCodeNames');
					sucCalback.call(this);
				}else {
					errCallback(res);
				}
			},
			function (res) {
				errCallback(res);
				//alert("[" + res.code + "] "+ res.message);
				//return false;
			});
	}

	let render2 = function(fncallback){
		createGrid();
		bindEvent();
		let params = {upperCd:'env.lang'};
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmn/cmmncode/list', JSON.stringify(params), 'application/json', true,
			function (res) {
				if (res.code === 'OK') {
					renderLangCodeNames(res.data);
					fncallback.call(this);
				}else {
					ocb.cmm.errMsgHandler(res);
				}
			},
			function (res) {
				alert("[" + res.code + "] "+ res.message);
				return false;
			});

		SBUxMethod.attr('btn_del','disabled','true');
	};

	let renderLangCodeNames = function(langNameList){
		if(!langNameList || !langNameList.length || langNameList.length === 0){
			langNameList = [];
			langNameList.push({langCd:'ko', cdNm:'한국어'});
		}
		$("#langCodeNameTable > tbody").empty();

		langNameList.forEach(function(ele){
			let html = '<tr><th>'+ ele.cdNm +'</th><td>\n' +
				'<input type="text" id="langCodeName_'+ ele.cd +'" name="langCodeName" langcode="'+ ele.cd +'" maxlength="50" style="width:100%;"></input>\n' +
				'</td>\n' +
				'</tr>';
			$('#langCodeNameTable > tbody:last').append(html);
			//SBUxMethod.render();
		});

	}

	let bindEvent = function(){
		if(isEventBinded == true){
			return;
		}
		o.dataGridId.bind('click', 'cmmCdMgtEx.gridClick');
		o.dataGridId.bind('dblclick', 'cmmCdMgtEx.gridDblclick');
		/*
		$("#btnSearchGrid").click(function(){

		});
		*/
		$("#btn_add").click(function(){
			clearFormData();
		});
		$("#btn_save").click(function(){
			saveFormData();
		});
		$("#btn_del").click(function(){
			deleteFormData();
		});

		isEventBinded = true;
	};

	let loadInitData = function(){
		loadGridData();
	}

	let createGrid = function(callback){
		o.gridProps.parentid = 'sbGridArea';
		o.gridProps.id = 'cmmCdMgtEx.dataGridId';
		o.gridProps.jsonref = 'cmmCdMgtEx.gridDataList';
		o.gridProps.filtering = true;
		o.gridProps.tree = { col : 0, levelref : 'level', open : true, lock : true, openlevel : 0, checkboxchildrencheck : false };
		//o.gridProps.extendlastcol = 'scroll';
		o.gridProps.columns = [
			{
				caption: [gridHeaderNameText],
				ref: 'cdNm',
				width: '50%',
				style: 'text-align:center',
				type: 'output',
				filtering : {listsearch : true}
			},
			{
				caption: [gridHeaderCodeText],
				ref: 'cd',
				width: '35%',
				style: 'text-align:center',
				type: 'output',
				filtering : {listsearch : true}
			},

			{
				caption: [gridHeaderUseYnText],
				ref: 'useYn',
				width: '15%',
				style: 'text-align:center',
				type: 'output'
			}
		];
		o.dataGridId = _SBGrid.create(o.gridProps);
		callback();
	}

	let loadGridData = function(upperCd, cd, rowIdx){
		let pm = {};
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmncode/codemgt/allCodes/list', pm, 'application/json', true,
			function (res) {
				if (res.code === 'OK') {
					let retObj = res.data;
					o.gridDataList = retObj;
					//o.dataGridId.rebuild();
					o.dataGridId.refresh();
					let selectedRows = o.dataGridId.getSelectedRows();
					let selectedCnt = selectedRows.length ? selectedRows.length : 0;
					if(selectedCnt === 0 ) {
						o.dataGridId.clickRow(getGridIndex(upperCd, cd, retObj, rowIdx) + 1, true);
					}
				}else {
					ocb.cmm.errMsgHandler(res);
				}
				console.log('22222222 loadGridData suc');
			},
			function (res) {
				alert("[" + res.code + "] "+ res.message);
				return false;
			});
	}

	let getGridIndex = function(upperCd, cd, dataList, rowIndex){
		if(!dataList || !dataList.length || dataList.length === 0){
			return 0;
		}

		if(!upperCd || !cd){
			return 0;
		}

		if(rowIndex && rowIndex > 0 ){
			return rowIndex;
		}

		let idxList = [];
		dataList.filter(function(ele, index){
			if( (ele.upperCd && ele.upperCd === upperCd) && (ele.cd && ele.cd === cd) ){
				idxList.push(index);
				return true;
			}
		});
		if(idxList.length === 0){
			idxList.push(0);
		}
		return idxList[0];
	}

	let bindFormData = function(rowObj){
		if(!rowObj) return;
		$("#dlngCd").val('update');
		$("#upperCdNmText").text(ocb.cmm.getValue(rowObj.upperCd));
		$("#upperCd").val(ocb.cmm.getValue(rowObj.upperCd));
		$("#cd").val(ocb.cmm.getValue(rowObj.cd));
		$("#oriCd").val(ocb.cmm.getValue(rowObj.cd));

		let useYn = ocb.cmm.getValue(rowObj.useYn);
		if(useYn === 'Y'){
			$("#useYnY").prop('checked', true);
		}else if(useYn === 'N'){
			$("#useYnN").prop('checked', true);
		}else{
			$("#useYnY").prop('checked', false);
			$("#useYnN").prop('checked', false);
		}
		$("#langCodeName_ko").val(ocb.cmm.getValue(rowObj.cdNm));
		let nameLangList = rowObj.codeNameList;
		if(nameLangList && nameLangList.length && nameLangList.length > 0) {
			nameLangList.forEach(function(ele){
				let langCd = ocb.cmm.getValue(ele.langCd);
				if(langCd !== '' || langCd === 'ko'){
					// pass
				} else {
					let inputObj = $("#langCodeName_" + ele.langCd);
					if(inputObj){
						inputObj.val(ocb.cmm.getValue(ele.cdNm));
					}
				}
			});
		}

		$("#sortOrdr").val(ocb.cmm.getIntValue(rowObj.sortOrdr, 100));
		$("#adit1Dc").val(ocb.cmm.getValue(rowObj.adit1Dc));
		$("#adit2Dc").val(ocb.cmm.getValue(rowObj.adit2Dc));
		$("#remark").val(ocb.cmm.getValue(rowObj.dc));
		SBUxMethod.attr('btn_del','disabled','false');
	}

	let clearFormData = function(){
		let curntCd = ocb.cmm.getValue($("#cd").val());
		if(curntCd === ''){
			$("#upperCdNmText").text('HOME');
			$("#upperCd").val('HOME');
		} else {
			$("#upperCdNmText").text(curntCd);
			$("#upperCd").val(curntCd);
		}

		$("#dlngCd").val('add');
		$("#cd").val('');
		$("#oriCd").val('');
		$("#useYnY").prop('checked', true);
		$("#sortOrdr").val("100");
		$("#adit1Dc").val('');
		$("#adit2Dc").val('');
		$("#remark").val('');

		let langRows = $("input[name=langCodeName]");
		langRows.each(function(idx, ele){
			$(this).val('');
		})
		SBUxMethod.attr('btn_del','disabled','true');
	}

	let getFormData = function(){
		let dlngCd = $("#dlngCd").val();
		let upperCdNmText = $("#upperCdNmText").text();
		let upperCd = $("#upperCd").val();
		let cd = $("#cd").val();
		let oriCd = $("#oriCd").val();
		let useYn = $("input[name='useYn']:checked").val();
		let sortOrdr = $("#sortOrdr").val();
		let adit1Dc = $("#adit1Dc").val();
		let adit2Dc = $("#adit2Dc").val();
		let remark = $("#remark").val();

		let langList = [];
		let langRows = $("input[name=langCodeName]");
		let defaultLangCd = 'ko';
		let defaultLangName = '';
		langRows.each(function(idx, ele){
			let langCd = $(this).attr('langcode');
			let langNm = $(this).val();
			if(langCd === 'ko'){
				defaultLangName = langNm;
			}
			if(langNm !== '') {
				langList.push({upperCd: upperCd, cd: cd, langCd: langCd, cdNm: langNm});
			}
		});

		let daObj = {};
		daObj.convert = dlngCd;
		daObj.upperCd = upperCd;
		daObj.originalCode = oriCd;	// 수정인 경우 수정이전의 코드.
		daObj.cd = cd;
		daObj.cdNm = defaultLangName;
		daObj.sortOrdr = sortOrdr;
		daObj.useYn = useYn;
		daObj.delYn = 'N';
		daObj.dc = remark;
		daObj.adit1Dc = adit1Dc;
		daObj.adit2Dc = adit2Dc;
		daObj.name = langList;	// 언어 이름 목록

		return daObj;
	}

	let saveFormData = function(){
		let dataObj = getFormData();
		let dlngCd = dataObj.convert;
		if(!dlngCd || !(dlngCd === 'add' || dlngCd === 'update')){
			alert(alertMsgUnknownErr);
			return false;
		}

		let cd = ocb.cmm.getValue(dataObj.cd);
		let useYn = ocb.cmm.getValue(dataObj.useYn);
		if(cd === ''){
			alert(alertMsgCodeRequired);
			return false;
		}

		if(!(useYn === 'Y' || useYn === 'N')){
			alert(alertMsgUseYnSelect);
			return false;
		}

		let langList =  dataObj.name;
		let langSize = langList.length ? langList.length:0;
		if(langSize === 0){
			alert(alertMsgCodeNameRequired);
			return false;
		}

		let koLangCount = 0;
		langList.forEach(function(ele){
			if(ele.langCd === 'ko' && ele.cdNm !== ''){
				koLangCount += 1;
			}
		});
		if(koLangCount === 0){
			alert(alertMsgCodeNameKoRequired);
			return false;
		}

		let sortOrdr = ocb.cmm.getIntValue(dataObj.sortOrdr, -1);
		if(sortOrdr < 0){
			alert(alertMsgSortOdrOnlyNumber);
			return false;
		}
		let dlngName = "";
		if(dlngCd === 'update'){	// 수정
			dlngName = confirmMsgUpdTitle;
			let oriCd = ocb.cmm.getValue(dataObj.originalCode);	// 수정인 경우 수정이전의 코드.
			if(oriCd === ''){
				alert(alertMsgUnknownErr);
				return false;
			}
		} else {	// 등록
			dlngName = confirmMsgRegTitle;
			let oriCd = $("#oriCd").val();
			dataObj.originalCode = cd;		// 등록인 경우도 체크하므로 일단 전송.
		}

		let confirmMsg = dlngName +' '+ confirmMsgAsking;
		if(confirm(confirmMsg)){
			ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmncode/codemgt/code/set', JSON.stringify(dataObj), 'application/json', true,
				function (res) {
					if (res.code === 'OK') {
						if(dlngCd === 'add'){
							o.dataGridId.clearSelection();
						}
						loadGridData(dataObj.upperCd, dataObj.cd, 0);
						alert(processedMsgOk);
					}else {
						ocb.cmm.errMsgHandler(res);
					}
				},
				function (res) {
					alert("[" + res.code + "] "+ res.message);
					return false;
				});
		}

		return true;
	}

	let deleteFormData = function(upperCd, cd){

		let dataObj = getFormData();
		let dlngCd = dataObj.convert;
		if(!dlngCd || dlngCd === 'add'){
			console.log('invalid action..', dataObj);
			return false;
		}
		let pupCd = ocb.cmm.getValue(dataObj.upperCd);
		let pcd = ocb.cmm.getValue(dataObj.originalCode);
		if(pupCd === ''){
			alert(alertMsgUnknownErr);
			return false;
		}
		if(pcd === ''){
			alert(alertMsgUnknownErr);
			return false;
		}

		let searchParams = {upperCd: pcd};
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmn/cmmncode/list', JSON.stringify(searchParams), 'application/json', true,
			function (res) {
				if (res.code === 'OK') {
					let subListCnt = res.data.length ? res.data.length : 0;
					if(subListCnt === 0 ){
						let confirmMsg = confirmMsgDelTitle +' '+ confirmMsgAsking;
						if(confirm(confirmMsg)) {
							sendDeleteFormData(pupCd, pcd);
						}
					} else {
						alert(alertMsgExistLowerCd);
						return false;
					}
				}else {
					ocb.cmm.errMsgHandler(res);
				}
			},
			function (res) {
				alert("[" + res.code + "] "+ res.message);
				return false;
			});
	}

	let sendDeleteFormData = function(pupCd, pcd){
		let param = {upperCd: pupCd, cd: pcd};
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/cmmncode/codemgt/code/remove', JSON.stringify(param), 'application/json', true,
			function (res) {
				if (res.code === 'OK') {
					let curIdx = 0;
					let selectedRows = o.dataGridId.getSelectedRows();
					if(selectedRows && selectedRows.length && selectedRows.length > 0 ) {
						curIdx = selectedRows[0] - 2;
					}
					o.dataGridId.clearSelection();
					loadGridData(pupCd, pcd, curIdx > 0 ? curIdx:0);
					alert(confirmMsgDelTitle +' '+ processedMsgOk);
				}else {
					ocb.cmm.errMsgHandler(res);
				}
			},
			function (res) {
				alert("[" + res.code + "] "+ res.message);
				return false;
			});
	}

	return o;
})();
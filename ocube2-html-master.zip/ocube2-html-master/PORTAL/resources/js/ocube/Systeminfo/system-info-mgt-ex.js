
var sysinfo = (function(){
	let cp = {};
	let g_grpId;
	let g_grpNm;
	cp.init = function(globalOpt){		
		//g_grpId = globalOpt.grpId; //emp에 grpId가 누락되어 있어 임시로 박아놓음
		//g_grpNm = globalOpt.grpNm; //emp에 grpNm가 누락되어 있어 임시로 박아놓음
		g_grpId = "G1000"
		g_grpNm = "오웬스그룹TEST";
		initDataLoad(this);			// 데이터 로드
	}

	
	var initDataLoad = function(obj){
		sysinfolist();
	}

	var sysinfolist = function() {

		let params = {};
		params.grpId =  g_grpId;

		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/system/info/get',
			JSON.stringify(params), 'application/json', true,

			function (res) {

				$("#info").text(res.data.webConectAddr);
				SBUxMethod.set("title", res.data.webSj);
				SBUxMethod.set("mangeemail", res.data.trnsmrEmailAddr);
				SBUxMethod.set("emailsender", res.data.trnsmrNm);
				SBUxMethod.set("SmtpUnUse", res.data.smtpSvrUseYn);
				SBUxMethod.set("smtpserver", res.data.smtpSvrDomn);
				SBUxMethod.set("smtpid", res.data.smtpId);
				SBUxMethod.set("smtpport", res.data.smtpPortNo);
				SBUxMethod.set("smtppwd", res.data.smtpPwd);
				SBUxMethod.get("SmtpUnUse") === "Y" ? $('.smtpSvrUseYn').show() : $('.smtpSvrUseYn').hide();

			},
			function (res) {

				ocb.cmm.errMsgHandler(res);
				return false;
			});

	};

	cp.setSmtpUnUse = function(res) {
		SBUxMethod.get("SmtpUnUse") === "Y" ? $('.smtpSvrUseYn').show() : $('.smtpSvrUseYn').hide();

		SBUxMethod.set("mangeemail", res.data.trnsmrEmailAddr);
		SBUxMethod.set("emailsender", res.data.trnsmrNm);
		SBUxMethod.set("smtpserver",  res.data.smtpSvrDomn);
		SBUxMethod.set("smtpserver", res.data.smtpSvrDomn);
		SBUxMethod.set("smtpid", res.data.smtpId);
		SBUxMethod.set("smtpport", res.data.smtpPortNo);
		SBUxMethod.set("smtppwd", res.data.smtpPwd);
	}


	cp.saveSysInfo = function() {

		let params = {};
		let webSj = SBUxMethod.get('title');
		let trnsmrEmailAddr = SBUxMethod.get('mangeemail');
		let trnsmrNm = SBUxMethod.get('emailsender');
		let smtpSvrDomn = SBUxMethod.get('smtpserver');
		let smtpPortNo = SBUxMethod.get('smtpport');
		let smtpId = SBUxMethod.get('smtpid');
		let smtpPwd = SBUxMethod.get('smtppwd');

		let emailExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;

		//추후 체크로직 분리
		if (!webSj) {
			alert('타이틀은 필수 입니다.');
			SBUxMethod.focus('title');
			return false;
		}

		let smtpSvrUseYn = SBUxMethod.get('SmtpUnUse');
		if (!smtpSvrUseYn) {
			alert('설정여부를 선택해 주세요.');
			return false;
		}

		if (smtpSvrUseYn === 'Y') {
			if (!trnsmrEmailAddr) {
				SBUxMethod.focus('mangeemail');
				alert('관리 이메일을 입력해 주세요.');
				return false;
			}
			if (trnsmrEmailAddr.match(emailExp) != null) {

			}else{
				alert('이메일 형식에 맞게 입력해 주세요.');
				return false;
			}
			if (!trnsmrNm) {
				alert('발신자명을 입력해 주세요.');
				SBUxMethod.focus('emailsender');
				return false;
			}

			if (!smtpSvrDomn) {
				alert('SMTP 서버를 입력해 주세요.');
				SBUxMethod.focus('smtpserver');
				return false;
			}
			if (!smtpPortNo) {
				alert('SMTP 포트를 입력해 주세요.');
				SBUxMethod.focus('smtpport');
				return false;
			}
			if (!smtpId) {
				alert('SMTP 아이디를 입력해 주세요.');
				SBUxMethod.focus('smtpid');
				return false;
			}
			if (!smtpPwd) {
				alert('SMTP 비밀번호를 입력해 주세요.');
				SBUxMethod.focus('smtppwd');
				return false;
			}
		}

		params.grpId = g_grpId;
		params.grpNm = g_grpNm;
		params.webSj = webSj;
		params.smtpSvrUseYn = smtpSvrUseYn;
		params.trnsmrEmailAddr = trnsmrEmailAddr;
		params.trnsmrNm = trnsmrNm;
		params.smtpSvrDomn = smtpSvrDomn;
		params.smtpId = smtpId;
		params.smtpPortNo = smtpPortNo;
		params.smtpPwd = smtpPwd;

		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/system/info/set',
			JSON.stringify(params),'application/json', true,
			function (res) {
				if (res.code === "OK") {
					if (res.message === "Success.") {
						alert("시스템 정보 저장에 성공하였습니다.");
					}
				}

			},
			function (res) {
				ocb.cmm.errMsgHandler(res);
				return false;
			});
	}
	
	cp.fnChangeSmtpUseYn = function(val) {
		setSmtpUseAreaHiddenYn(val === "Y" ? 'visible' : 'hidden');
	}
	cp.fnChangeSearch = function(val){
		let param = {};
		param.cmpnyId = SBUxMethod.getValue('select_cmpny');
		param.useYn = SBUxMethod.getValue('select_useYn');
		getGridCompanyList(param);
	}
	return cp;
})();
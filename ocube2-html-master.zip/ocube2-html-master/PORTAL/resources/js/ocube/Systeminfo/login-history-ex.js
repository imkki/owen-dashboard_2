var hisMgt = (function () {
    let his = {};

    his.selLoginHisTemp = [
        {
            text: "전체",
            value: ''
        },
        {
            text: "성공",
            value: 'SUCCESS'
        },
        {
            text: "실패",
            value: 'FAIL'
        }
    ]
    his.hisDataGrid;
    his.hisProperties = {};
    his.hisData = {
        resources: []
    }

    his.init = function (globalOpt) {
        renderComp(this);
        attachEvent(this);
        initDataLoad(this);
    };

    let renderComp = function (obj) {
        loginHistoryGrid();
    };

    let attachEvent = function (obj) {
    };

    let initDataLoad = function (obj) {
        setDatePick();
    };

    let loginHistoryGrid = function () {

        his.hisProperties.parentid = 'login_history';
        his.hisProperties.id = 'hisMgt.hisDataGrid';
        his.hisProperties.jsonref = 'hisMgt.hisData.resources';
        his.hisProperties.paging = {'type': 'page', 'count': 5, 'size': 10, 'sorttype': 'all', 'showgoalpageui': true};
        his.hisProperties.emptyrecords = '검색하여 주시기 바랍니다.';
        his.hisProperties.columns = [

            {caption: ['일시'], ref: 'insertDt', width: '15%', style: 'text-align:center', type: 'output'},
            {caption: ['아이디'], ref: 'loginId', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['회사'], ref: 'cmpnyNm', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['부서'], ref: 'deptNm', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['이름'], ref: 'empNm', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['접속기기'], ref: 'deviceInfo', width: '12.5%', style: 'text-align:center', type: 'output'},
            {caption: ['접속IP'], ref: 'conectIp', width: '12.5%', style: 'text-align:center', type: 'output'},
            {caption: ['클라이언트종류'], ref: 'deviceGb', width: '10%', style: 'text-align:center', type: 'output'},
            {caption: ['로그인결과'], ref: 'resultGb', width: '10%', style: 'text-align:center', type: 'output'}
        ]
        his.hisDataGrid = _SBGrid.create(his.hisProperties);
        his.hisDataGrid.bind("beforepagechanged", gridPagingClick);
        his.hisDataGrid.bind("afterpagechanged", "appendGridPageUI");
        his.hisDataGrid.bind("afterrefresh", "appendGridPageUI");
        his.hisDataGrid.bind("afterrebuild", "appendGridPageUI");
    };

    let setDatePick = function () {
        SBUxMethod.set('picker_start',moment().subtract(7, 'days').format('YYYY-MM-DD'));
        SBUxMethod.set('picker_end', moment().format('YYYY-MM-DD'));
        his.dateSchBtn();
    }
    
    let gridPagingClick = function (){
        var param = {};
        his.dateSchBtn(param);
    }

    let gridTxtChenge = function (){
        var param = {};
        var txt = "성공";

        if (value === 'SUCCESS') {
            txt = "성공";
        } else if (value === 'FAIL') {
            txt = "실패";
        }

        his.dateSchBtn(param);
    }

    his.dateSchBtn = function (){
        let param = {};
        let beginDd = SBUxMethod.get('picker_start');
        let endDd = SBUxMethod.get('picker_end');
        let empNm = SBUxMethod.get('input_sch_lo_name');
        param.pageVO = ocb.cmm.getGridPagingParam(his.hisDataGrid);

        if (!beginDd) {
            alert('검색할 시작 날짜를 선택 해주세요.');
            SBUxMethod.focus('picker_start');
            return false;
        }

        if (!endDd) {
            alert('검색할 종료 날짜를 선택 해주세요.');
            SBUxMethod.focus('picker_end');
            return false;
        }

        let dateStart = moment(SBUxMethod.get('picker_start'));
        let dateEnd = moment(SBUxMethod.get('picker_end'));
        if(dateStart > dateEnd){
            alert("시작 날짜가 더 클 수 없습니다.")
            return false;
        }

        param.resultGb = SBUxMethod.getValue('select_loginhis');
        param.beginDd = beginDd;
        param.endDd = endDd;
        param.empNm = empNm;
        param.page = param.pageVO.page;
        param.pageSize = param.pageVO.pageSize;

        ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/login/history/page/list', JSON.stringify(
            param), 'application/json', true,

            function (res) {
                let retObj = res.data;
                console.log("res ? ",res);
                his.hisData.resources = retObj.list;

                var totalCnt = 0;
                if (retObj.totalCnt > 0) {
                    totalCnt = retObj.totalCnt;
                }
                his.hisDataGrid.setPageTotalCount(totalCnt);
                his.hisDataGrid.refresh();
            },
            function (res) {
                ocb.cmm.errMsgHandler(res);
                return false;
            });
    };

    return his;
})();

// 탭 json
var menuTabData = [
	{
		"id": "USER",
		"pid": "-1",
		"order": "2",
		"text": "사용자",
		"targetid": "userMenuTab"
	},
	{
		"id": "ADMIN",
		"pid": "-1",
		"order": "1",
		"text": "관리자",
		"targetid": "adminMenuTab"
	}
];

// 사용여부
var selectUseYnData = [
	{text: "전체", value: ""},
	{text: "사용", value: "Y"},
	{text: "미사용", value: "N"}
];



var radioUseYnData = [
	{ text : "사용",			value : "Y"},
	{ text : "미사용",		value : "N"}
];

// 명칭 그리드
var menuLangListGrid;
var menuLangGridProperties = {};
var langData = {
	resources : []
}
// 권한 그리드
var menuAuthzListGrid;
var menuAuthzGridProperties = {};
var authzData = {
	resources : []
}

//상위메뉴
var upperMenuList = [];
var menuList = [];
var G_menuList = [];
var authzList = [];

var searchTxtData = [];
let G_menu_id;
let G_cmpny_id;
let G_grp_id;
let G_menu_gb;
let G_msg;
var menuinfo = (function(){
	let mi = {};
	mi.init = function(globalOpt){
		G_msg = globalOpt.springMsg;
		empInfo = ocb.cmm.getMyEmpInfo();
		G_grp_id = empInfo.grpId;
		G_cmpny_id = empInfo.cmpnyId;
		renderComp(this);
		initDataLoad(this);
	}

	var renderComp = function(obj) {
		menuLangGrid();
		//menuAuthzGrid();
	}

	var initDataLoad = function(obj) {
		var param = {};
		param.cmpnyId = G_cmpny_id;
		param.authzGb = SBUxMethod.get('menuTab') === "userMenuTab" ? "USER" : "ADMIN";
		getMenuList(param);
	}

	var menuLangGrid = function(){

		menuLangGridProperties.parentid = 'menuLangDiv';
		menuLangGridProperties.id = 'menuLangListGrid';
		menuLangGridProperties.jsonref = 'langData.resources';
		menuLangGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		menuLangGridProperties.columns = menuNmColumns();
		menuLangListGrid = _SBGrid.create(menuLangGridProperties);
	};

	var menuAuthzGrid = function(){

		menuAuthzGridProperties.parentid = 'menuAuthzListDiv';
		menuAuthzGridProperties.id = 'menuAuthzListGrid';
		menuAuthzGridProperties.jsonref = 'authzData.resources';
		menuAuthzGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		menuAuthzGridProperties.columns = menuAuthzColumns();
		menuAuthzListGrid = _SBGrid.create(menuAuthzGridProperties);
	};

	mi.info = function (obj) {
		console.log("info click", obj.attrObj);
		var param = {};
		param.id = obj.attrObj.id;
		G_menu_id = obj.attrObj.id;
		getMenuInfo(param);
	}

	mi.searchEnter = function(obj) {
		let deptNm = SBUxMethod.get('searchTxt').trim();
		let dept = searchTxtData.find(function (ele){ return ele.text === deptNm; });
		if( !dept && deptNm !== '' ) {
			alert("입력한 부서가 존재하지 않습니다. 다시 입력해 주세요.")
			SBUxMethod.set('searchTxt', '');
			SBUxMethod.focus('searchTxt');
			return;
		}

		SBUxMethod.setText('menu', obj, { extValue : 'expandParents' })
		var param = {};
		searchTxtData.forEach(function(ele){
			if (ele.text === obj) {
				param.id = ele.value;
			}
		});

		getMenuInfo(param);

	}

	mi.searchUseYn = function(obj) {
		var param = {};
		param.cmpnyId = G_cmpny_id;
		param.useYn = obj;
		param.authzGb = SBUxMethod.get('menuTab') === "userMenuTab" ? "USER" : "ADMIN";
		getMenuList(param);
	}

	mi.tabClick = function() {

		var param = {};
		param.authzGb = SBUxMethod.get('menuTab') === "userMenuTab" ? "USER" : "ADMIN";
		param.cmpnyId = G_cmpny_id;
		getMenuList(param);
		var modelName = SBUxMethod.get('menuTab') === "userMenuTab" ? 'menu' : 'adminMenu';

		if (SBUxMethod.getAttr(modelName).uitype === "checkbox") {
			SBUxMethod.attr(modelName,'uitype','normal');
		}
	}

	mi.addMenuInfo = function() {
		SBUxMethod.set("menuCdTxt","");
		SBUxMethod.set("urlTxt","");
		SBUxMethod.set("authzLabel","");
		SBUxMethod.set("useYnRadio","Y");
		SBUxMethod.set("orderTxt","");

		langData.resources = [{"langCd":"ko", "menuNm":""}]
		_SBGrid.getGrid('menuLangListGrid').refresh();
	}

	mi.removeMenuInfo = function() {

		var modelName = SBUxMethod.get('menuTab') === "userMenuTab" ? 'menu' : 'adminMenu';
		if (SBUxMethod.getAttr(modelName).uitype != "checkbox") {

			SBUxMethod.attr(modelName,'uitype','checkbox');

		} else if (SBUxMethod.getAttr(modelName).uitype === "checkbox") {
			if (typeof SBUxMethod.getTreeStatus(modelName) === 'undefined') {

				SBUxMethod.attr(modelName,'uitype','normal');

			} else {

				var param = {}
				param.delYn = "Y";
				param.menuList = []
				param.cmpnyId = G_cmpny_id;

				var list = SBUxMethod.getTreeStatus(modelName);
				for (var i = 0; i < list.length; i++) {
					param.menuList.push(list[i].id);
				}

				var send = confirm("선택된 [" + param.menuList.length +"]건을 삭제하시겠습니까?");
				if (send) {
					ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/manage/info/remove', JSON.stringify(param), 'application/json', true, function (res) { // success callback
						if (res.code === 'OK') {
							alert('삭제하였습니다.');
							SBUxMethod.attr(modelName, 'uitype', 'normal');
							param.authzGb = SBUxMethod.get('menuTab') === "userMenuTab" ? "USER" : "ADMIN";
							getMenuList(param);
						} else {
							alert(res.message);
						}
					}, function (res) {
						alert(res.message);
					});
				}
			}
		}
	}

	mi.menuSaveBtn = function() {

		var param = {};
		param.cmpnyId = G_cmpny_id;
		param.id = SBUxMethod.get("menuCdTxt");
		param.pid = SBUxMethod.get("upperMenu");
		param.menuGb = SBUxMethod.get("upperMenu") === "E_AS0000" ? "SYSTEM" : "HUMAN";
		param.link = SBUxMethod.get("urlTxt");
		param.useYn = SBUxMethod.get("useYnRadio");
		param.delYn = "N";
		param.authzGb = SBUxMethod.get('menuTab') === "userMenuTab" ? "USER" : "ADMIN";
		param.order = SBUxMethod.get("orderTxt");
		param.menuLangList = [];

		var langData = menuLangListGrid.getGridDataAll();

		for (var i=0; i<langData.length; i++) {
			param.menuLangList.push({"menuId" : SBUxMethod.get("menuCdTxt"), "langCd" : langData[i].langCd, "menuNm" : langData[i].menuNm});
			if (langData[i].langCd === "ko") {
				param.text = langData[i].menuNm;
			}
		}

		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/manage/info/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				alert('저장하였습니다.');
				param.id = "";
				param.useYn = "";
				getMenuList(param);
			} else {
				alert(res.message);
			}
		}, function(res){
			alert(res.message);
		});
	}

	var getMenuList = function(param) {
		//console.log("getMenuList param ? ", param);
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				console.log("getMenuList retObj ? ", retObj);
				if (retObj) {
					G_menuList = retObj ? retObj:[];
					menuList = retObj ? retObj:[];
					upperMenuList = retObj ? retObj:[];
					searchTxtData = retObj ? retObj:[];

					searchTxtData.forEach(function(ele){
						ele.value = ''+ ele.id;
						ele.label = ele.text ? ''+ ele.text:'';
					});

					menuList.forEach(function(ele){
						ele.id = ''+ ele.id;
						ele.pid = ele.pid ? ''+ ele.pid:'';
						delete ele.menuAuthzList;
						delete ele.authzMapngList;
					});
					upperMenuList.forEach(function(ele){
						ele.value = ''+ ele.id;
						ele.text = ele.text ? ''+ ele.text:'';
					});

					SBUxMethod.refresh('searchTxt');
					SBUxMethod.refresh('menu');
					SBUxMethod.refresh('adminMenu');
					SBUxMethod.refresh('upperMenu');

				}
			} else {
				alert(res.data.message);
			}
		}, function(res){
			alert(res.data.message);
		});
	}

	var getMenuInfo = function(param) {
		console.log("getMenuInfo param > ", param);
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/manage/info/get', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			console.log("getMenuInfo res > " , res);
			if( res.code === 'OK' ){
				SBUxMethod.set('upperMenu', res.data.pid);
				SBUxMethod.set('menuCdTxt', res.data.id);
				SBUxMethod.set('urlTxt', res.data.link);
				SBUxMethod.set('orderTxt', res.data.order);
				SBUxMethod.set('useYnRadio', res.data.useYn);
				G_menu_gb = res.data.authzGb;
				var authzLabel = "";
				authzList = res.data.menuAuthzList ? res.data.menuAuthzList : [];
				authzList.forEach(function (ele){
					ele.authzCd = ''+ ele.authzCd;
					ele.authzNm = ele.authzNm ? ''+ ele.authzNm:'';
				});


				for (var i=0; i<authzList.length; i++) {

					if (i != authzList.length -1 ) {
						authzLabel += authzList[i].authzNm + ", " ;
					} else {
						authzLabel += authzList[i].authzNm ;
					}
				}
				SBUxMethod.set('authzLabel', authzLabel);

				if (res.data.menuLangList.length == 0) {
					langData.resources = [{"langCd":"ko", "menuNm": res.data.text}];
				} else if (res.data.menuLangList.length != 0) {
					langData.resources = res.data.menuLangList;

				}
				_SBGrid.getGrid('menuLangListGrid').refresh();
			} else {
				alert(res.message);
			}
		}, function(res){
			alert(res.message);
		});
	}

	mi.makeAuthzGrid = function() {
		menuAuthzGrid();
		if (authzList.length != 0) {
			authzData.resources = authzList;
		}
		_SBGrid.getGrid('menuAuthzListGrid').refresh();
	}

	mi.addAuthzRow = function() {
		var authzCd = SBUxMethod.get("authzCdTxt");
		var authzNm = SBUxMethod.get("authzNmTxt");

		if (typeof authzCd === 'undefined') {
			alert("코드는 필수입니다.");
			return;
		}

		if (typeof authzNm === 'undefined') {
			alert("이름은 필수입니다.");
			return;
		}

		menuAuthzListGrid.addRows([{"authzCd" : authzCd, "authzNm" : authzNm}]);
		menuAuthzListGrid.refresh();
	}

	mi.removeAuthzRow = function() {
		console.log("menuAuthzListGrid.getRow() ? ", menuAuthzListGrid.getRow());
		menuAuthzListGrid.deleteRow(menuAuthzListGrid.getRow());
	}

	mi.addAuthzInfo = function() {
		var param = {};
		param.id = SBUxMethod.get("menuCdTxt");
		param.menuAuthzList = [];
		var authzData = menuAuthzListGrid.getGridDataAll();

		if (typeof param.id === 'undefined') {
			alert("선택된 메뉴 정보가 없습니다.");
			return;
		}

		for (var i=0; i<authzData.length; i++) {
			param.menuAuthzList.push({"menuId" : param.id, "authzCd" : authzData[i].authzCd, "authzNm" : authzData[i].authzNm});
		}

		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/menu/manage/info/authz/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			console.log("res > " , res);
			if( res.code === 'OK' ){
				alert("메뉴 권한 정보를 저장했습니다.");
				SBUxMethod.closeModal("menuAuthzModal");
				getMenuInfo(param);
			} else {
				alert(res.message);
			}
		}, function(res){
			alert(res.message);
		});
	}

	mi.closeAuthzModal = function (){
		SBUxMethod.closeModal("menuAuthzModal");
	}

	var menuNmColumns = function(){
		return [
			{
				caption : ['언어']
				, ref : 'langCd'
				, width : '30%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function(langCd){
						return ocb.cmm.getLanguagesList(G_msg, langCd);
					}
				}
			}
			, {
				caption : ['명칭']
				, ref : 'menuNm'
				, width : '90%'
				, style : 'text-align:center'
				, type : 'input'
				, typeinfo : {
					maxlength : 30
				}
			}
		]
	}

	var menuAuthzColumns = function() {
		return [
			{
				caption : [''],
				ref : 'check',
				width : '4%',
				style : 'text-align:center',
				type : 'checkbox'
			},
			{
				caption : ['코드']
				, ref : 'authzCd'
				, width : '48%'
				, style : 'text-align:center'
				, type : 'output'

			}
			, {
				caption : ['명칭']
				, ref : 'authzNm'
				, width : '48%'
				, style : 'text-align:center'
				, type : 'output'
			}
		]
	}
	
	return mi;
	
})();

//연결 필요 
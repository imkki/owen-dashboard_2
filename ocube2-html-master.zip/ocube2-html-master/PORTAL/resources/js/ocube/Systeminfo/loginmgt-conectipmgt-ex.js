var cmpnyDatagrid;
var cmpnySBGridProps = {};
var cmpnyDataList = [];

var empDatagrid;
var empSBGridProps = {};
var empDataList = [];

var G_cmpny_nm_list = [];
var G_setup_no = 0;
var conectIpMgt = (function(){
	var o = {};
	/*const cmpnyGridPageSize = 20;
	const empGridPageSize = 20;*/

	o.selectUseYnData = [
		{"text":"전체", "value":""},
		{"text":"사용", "value":"Y"},
		{"text":"미사용", "value":"N"}
	];

	o.radioUseYnData = [
		{"text":"사용", "value":"Y"},
		{"text":"미사용", "value":"N"}
	];

	/*회사 목록*/
	o.cmpnyNmData = [];
	
	/*사원 목록*/
	o.empListData = [];

	o.init = function(globalOpt){
		render();
		bindEvent();
		loadDataInit();
	}

	o.fnTabClick = function(val){
		if(val == 'tab_allcmpny_iplimit_cfg'){
			if(!cmpnyDatagrid) {
				createCmpnyGrid([]);
				loadCmpnyData();
			}
		}else{
			if(!empDatagrid) {
				createEmpGrid([]);
				loadEmpData();
			}
		}
	}
	o.fnGridClickCmpny = function(){
		var nRow = cmpnyDatagrid.getRow();
		var rowObj = cmpnyDatagrid.getRowData(nRow,false);
		//console.log("[fnGridClickCmpny] rowObj=", rowObj)
		$("#cmpny_detail_blank").hide();
		$("#cmpny_detail_info").show();
		G_setup_no = rowObj.setupNo;
		SBUxMethod.set('allcmpnyCmpny', rowObj.cmpnyId);
		SBUxMethod.set('allcmpnyIpAddrStart', rowObj.beginIp);
		SBUxMethod.set('allcmpnyIpAddrEnd', rowObj.endIp);
		SBUxMethod.set('cmpnyUseYn', rowObj.useYn);
		SBUxMethod.set('allcmpnyOrderSn', rowObj.sortSn);
	}

	o.fnGridClickEmp = function(){
		var nRow = empDatagrid.getRow();
		var rowObj = empDatagrid.getRowData(nRow,false);
		//console.log("[fnGridClickCmpny] rowObj=", rowObj)
		$("#emp_detail_blank").hide();
		$("#emp_detail_info").show();
		G_setup_no = rowObj.setupNo;
		SBUxMethod.set('empName', rowObj.empNm);
		SBUxMethod.set('empIpAddrStart', rowObj.beginIp);
		SBUxMethod.set('empIpAddrEnd', rowObj.endIp);
		SBUxMethod.set('empUseYn', rowObj.useYn);
		SBUxMethod.set('empOrderSn', rowObj.sortSn);
	}

	o.fnIpSave = function(tabType) {
		var url = "";
		var txt = "";
		var param = {};
		var saveType = G_setup_no === 0 ? 'add' : 'set';
		if (tabType === "cmpny") {
			switch (saveType) {
				case 'add':
					url = page_context_path + "/rest/conectip/manage/cmpny/add";
					txt = "추가";
					break;
				case 'set':
					url = page_context_path + "/rest/conectip/manage/cmpny/set";
					txt = "수정";
					break;
				default: break;
			}
		} else if(tabType === "emp") {
			switch (saveType) {
				case 'add':
					url = page_context_path + "/rest/conectip/manage/emp/add";
					txt = "추가";
					break;
				case 'set':
					url = page_context_path + "/rest/conectip/manage/emp/set";
					txt = "수정";
					break;
				default: break;
			}
		}

		param.cmpnyId = tabType === "cmpny" ? SBUxMethod.get('allcmpnyCmpny') : "";
		param.empId = tabType === "cmpny" ? "" : SBUxMethod.get('empName');
		param.setupNo = G_setup_no;
		param.beginIp = tabType === "cmpny" ? SBUxMethod.get('allcmpnyIpAddrStart') : SBUxMethod.get('empIpAddrStart');
		param.endIp = tabType === "cmpny" ? SBUxMethod.get('allcmpnyIpAddrEnd') : SBUxMethod.get('empIpAddrEnd');
		param.useYn = tabType === "cmpny" ? SBUxMethod.get('cmpnyUseYn') : SBUxMethod.get('empUseYn');
		param.sortSn = tabType === "cmpny" ? SBUxMethod.get('allcmpnyOrderSn') : SBUxMethod.get('empOrderSn');

		if (!dataCheck(param)) {
			return;
		}
		//console.log("param ? ", param);
		ocb.restcli.exchangeAsync('POST', url, JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				alert(txt + " 했습니다.");
				switch (tabType) {
					case 'cmpny' :
						loadCmpnyData();
						break;
					case 'emp' :
						loadEmpData();
						break;
					default : break;
				}

			} else {
				alert('회사 정보를 불러오는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});

	}

	o.fnIpRemove = function(tabType, param) {
		var url = "";
		if (tabType === "cmpny") {
			url = page_context_path + "/rest/conectip/manage/cmpny/remove";
		} else if(tabType === "emp") {
			url = page_context_path + "/rest/conectip/manage/emp/remove";
		}
		//console.log("fnIpRemove param ? ", param);
		ocb.restcli.exchangeAsync('POST', url, JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				alert("삭제 했습니다.");
				switch (tabType) {
					case 'cmpny' :
						loadCmpnyData();
						break;
					case 'emp' :
						loadEmpData();
						break;
					default : break;
				}
			} else {
				alert('IP 정보를 삭제하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
	}

	o.checkIp = function(obj ,id){
		let reg = /[^0-9.]*/g;
		SBUxMethod.set(id, obj.replace( reg, "" ));
	}

	o.gridCmpnyPagingClick = function() {
		loadCmpnyData();
	}
	o.gridEmpPagingClick = function() {
		loadEmpData();
	}

	var render = function(){
		createCmpnyGrid([]);
	}

	var bindEvent = function(){
		// 전사설정 > 추가버튼 클릭
		$("#btn_allcmpny_iplimit_add").click(function (){

			$("#cmpny_detail_blank").hide();
			$("#cmpny_detail_info").show();

			G_setup_no = 0;
			SBUxMethod.set('allcmpnyCmpny', "");
			SBUxMethod.set('allcmpnyIpAddrStart', "");
			SBUxMethod.set('allcmpnyIpAddrEnd', "");
			SBUxMethod.set('cmpnyUseYn', "Y");
			SBUxMethod.set('allcmpnyOrderSn', "0");
		});

		// 전사설정 > 선택삭제버튼  클릭
		$("#btn_allcmpny_iplimit_del").click(function (){
			checkedRowDataCmpny();
		});
		// 전사설정 > 삭제버튼 클릭
		$("#btn_cmpny_del").click(function (){
			var param = {};
			param.connectIpList = [];
			param.connectIpList.push({"setupNo" : G_setup_no});
			var result = confirm("삭제하시겠습니까?");
			if (result) {
				conectIpMgt.fnIpRemove('cmpny', param);
			}
		});
		// 전사설정 > 저장버튼 클릭
		$("#btn_cmpny_save").click(function (){
			//alert('전사설정 저장버튼 클릭');
			conectIpMgt.fnIpSave('cmpny');
		});


		// 개인설정 > 추가버튼 클릭
		$("#btn_emp_iplimit_add").click(function (){

			$("#emp_detail_blank").hide();
			$("#emp_detail_info").show();

			G_setup_no = 0;
			SBUxMethod.set('empName', "");
			SBUxMethod.set('empIpAddrStart', "");
			SBUxMethod.set('empIpAddrEnd', "");
			SBUxMethod.set('empUseYn', "Y");
			SBUxMethod.set('empOrderSn', "0");
		});

		// 개인설정 > 선택삭제버튼 클릭
		$("#btn_emp_iplimit_del").click(function (){
			checkedRowDataEmp();
		});

		// 개인설정 > 삭제버튼 클릭
		$("#btn_emp_del").click(function (){
			var param = {};
			param.connectIpList = [];
			param.connectIpList.push({"setupNo" : G_setup_no});
			var result = confirm("삭제하시겠습니까?");
			if (result) {
				conectIpMgt.fnIpRemove('emp', param);
			}
		});
		// 개인설정 > 저장버튼 클릭
		$("#btn_emp_save").click(function (){
			conectIpMgt.fnIpSave('emp');
		});

		$("#btn_cmpny_search").click(function() {
			loadCmpnyData();
		});

		$("#btn_emp_search").click(function() {
			loadEmpData();
		});
	}

	var loadDataInit = function(){
		loadCmnpnySelectBox();
		loadCmpnyData();
		loadEmpSearchData();
	}

	var loadCmpnyData = function(){
		var cmpnyDataList = getAllCompanySampvarestData();
		rebuildCmpnyGrid(cmpnyDataList);
	}

	var loadEmpData = function(){
		var empDataList = getEmpSampvarestData();
		rebuildEmpGrid(empDataList);
	}

	var loadEmpSearchData = function() {
		var param = {};
		param.cmpnyMainYn = "Y";
		param.deptMainYn = "Y";
		conectIpMgt.empListData = ocb.cmm.getEmpList(param).empList;
		conectIpMgt.empListData.forEach(function(ele){
			ele.text =  ''+ ele.empNm;
			ele.value = ''+ ele.empId;
		});
		console.log("conectIpMgt.empListData ? ", conectIpMgt.empListData);
		SBUxMethod.refresh('empName');
	}

	var rebuildCmpnyGrid = function(rowsData){
		cmpnyDataList = rowsData;
		cmpnyDatagrid.rebuild();
	}

	var loadCmnpnySelectBox = function(){
		var param = {};
		conectIpMgt.cmpnyNmData = ocb.cmm.getCmpnyList(param).cmpnyList;
		conectIpMgt.cmpnyNmData.forEach(function(ele){
			ele.text =  ''+ ele.cmpnyNm;
			ele.value = ''+ ele.cmpnyId;
		});
		SBUxMethod.refresh('allcmpnyCmpny');
	}

	var createCmpnyGrid = function(rowsData){
		var paging = { 'type' : 'page', 'count' : 5, 'size' : 10, 'sorttype' : 'page', 'showgoalpageui' : false };	// 페이징 처리
		cmpnyDatagrid = sbuxComponent.makeGrid(cmpnyDatagrid , cmpnySBGridProps, 'SBGridArea1', 'cmpnyDatagrid','cmpnyDataList', '데이터가 존재하지 않습니다.',
			cmpnyGridColumns(), paging);
		cmpnyDatagrid.bind('click', 'conectIpMgt.fnGridClickCmpny');
		cmpnyDatagrid.bind("beforepagechanged", conectIpMgt.gridCmpnyPagingClick);
	};

	var rebuildEmpGrid = function(rowsData){
		empDataList = rowsData;
		empDatagrid.rebuild();
	}

	var createEmpGrid = function(rowsData){
		var paging = { 'type' : 'page', 'count' : 5, 'size' : 5, 'sorttype' : 'all', 'showgoalpageui' : false };	// 페이징 처리
		empDatagrid = sbuxComponent.makeGrid(empDatagrid , empSBGridProps, 'SBGridArea2', 'empDatagrid','empDataList', '데이터가 존재하지 않습니다.',
			empGridColumns(), paging);
		empDatagrid.bind('click', 'conectIpMgt.fnGridClickEmp');
		empDatagrid.bind("beforepagechanged", conectIpMgt.gridEmpPagingClick);
	}

	var checkedRowDataCmpny = function(){
		var cmnpyCheckedDatas = cmpnyDatagrid.getCheckedRowData(0);
		if(!cmnpyCheckedDatas || !cmnpyCheckedDatas.length || cmnpyCheckedDatas.length === 0){
			alert('선택된 데이터가 없습니다.');
			return;
		}
		//alert('['+ cmnpyCheckedDatas.length +'] 개 선택 됩');
		var param = {};
		param.connectIpList = [];
		cmnpyCheckedDatas.forEach(function(ele){
			//console.log('>>> checked data::', JSON.stringify(ele));
			param.connectIpList.push({"setupNo" : ele.data.setupNo})
		});
		var result = confirm("삭제하시겠습니까?");
		if (result) {
			conectIpMgt.fnIpRemove('cmpny', param);
		}
	}

	var checkedRowDataEmp = function(){
		var empCheckedDatas = empDatagrid.getCheckedRowData(0);
		if(!empCheckedDatas || !empCheckedDatas.length || empCheckedDatas.length === 0){
			alert('선택된 데이터가 없습니다.');
			return;
		}
		//alert('['+ empCheckedDatas.length +'] 개 선택 됩');
		var param = {};
		param.connectIpList = [];
		empCheckedDatas.forEach(function(ele){
			//console.log('>>> checked data::', JSON.stringify(ele));
			param.connectIpList.push({"setupNo" : ele.data.setupNo})
		});
		var result = confirm("삭제하시겠습니까?");
		if (result) {
			conectIpMgt.fnIpRemove('emp', param);
		}
	}

	var dataCheck = function(param) {
		var result = true;

		if (!param.beginIp) {
			alert("시작 IP가 누락되었습니다.");
			result = false;
		}

		if (!param.endIp) {
			alert("시작 IP가 누락되었습니다.");
			result = false;
		}

		return result;
	}

	var getAllCompanySampvarestData = function(){
		var cmpnyList = [];
		var param = ocb.cmm.getGridPagingParam(cmpnyDatagrid);
		param.useYn = SBUxMethod.get('select_cmpny_iplimit_useyn');;
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/conectip/manage/cmpny/page/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				var retObj = res.data;
				if (retObj) {
					var totalCnt = retObj.totalCnt;
					cmpnyList = retObj ? retObj.list:[];
					cmpnyList.forEach(function(ele){
						ele.setupNo = ele.setupNo;
						ele.cmpnyNm = ele.cmpnyNm;
						ele.startIpAddress = ele.beginIp;
						ele.endIpAddress = ele.endIp;
						ele.useYn = ele.useYn;
						ele.sortSn = ele.sortSn;
					});
					cmpnyDatagrid.setPageTotalCount(totalCnt);
				}
			} else {
				alert('회사 정보를 불러오는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return cmpnyList;
	}

	var getEmpSampvarestData = function(){
		var empList = [];
		var param = ocb.cmm.getGridPagingParam(empDatagrid);
		param.useYn = SBUxMethod.get('select_emp_iplimit_useyn');
		//console.log("getEmpSampvarestData param ? ", param);
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/conectip/manage/emp/page/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				var retObj = res.data;
				console.log("getEmpSampvarestData retObj ? ", retObj);
				if (retObj) {
					var totalCnt = retObj.totalCnt;
					empList = retObj ? retObj.list:[];
					empList.forEach(function(ele){
						ele.setupNo= ele.startupNo;
						ele.deptNm = ele.deptNm;
						ele.empNm = ele.empNm;
						ele.loginId = ele.loginId;
						ele.startIpAddress = ele.beginIp;
						ele.endIpAddress = ele.endIp;
						ele.useYn = ele.useYn;
						ele.sortSn = ele.sortSn;
					});
					empDatagrid.setPageTotalCount(totalCnt);
				}
			} else {
				alert('사원 정보를 불러오는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return empList;
	}

	var cmpnyGridColumns = function() {
		return [
			{
				caption : [''],
				ref : 'd',
				width : '6%',
				style : 'text-align:center',
				type : 'checkbox'
				/*,
				typeinfo : {
					fixedcellcheckbox :
						{
							usemode : true ,
							rowindex : 0 ,
							deletecaption : false
						}
				}*/
			},
			{
				caption : ['회사이름'],
				ref : 'cmpnyNm',
				width : '40%',
				style : 'text-align:center',
				type : 'output'
			},
			{
				caption : ['IP주소'],
				ref : 'startIpAddress',
				width : '40%',
				style : 'text-align:center',
				type : 'output',
					renderer:function(objGrid, nRow, nCol, strValue, objRowData) {
					return ''+ objRowData.startIpAddress +'~'+ objRowData.endIpAddress;
				}
			},
			{
				caption : ['사용여부'],
				ref : 'useYn',
				width : '20%',
				style : 'text-align:center',
				type : 'output',
					renderer:function(objGrid, nRow, nCol, strValue, objRowData) {
					return strValue === 'Y' ? '사용':'미사용';
				}
			}
		];
	}

	var empGridColumns = function() {
		return [
			{
				caption : [''],
				ref : 'd',
				width : '6%',
				style : 'text-align:center',
				type : 'checkbox'
				/*,
				typeinfo : {
					fixedcellcheckbox : {
						usemode : true ,
						rowindex : 0 ,
						deletecaption : false
					}
				}*/
			},
			{
				caption : ['대상자'],
				ref : 'empNm',
				width : '40%',
				style : 'text-align:center',
				type : 'output'
				, renderer:function(objGrid, nRow, nCol, strValue, objRowData) {
					return ''+ objRowData.deptNm +'/'+ strValue +'('+ objRowData.loginId +')';
				}
			},
			{
				caption : ['IP주소'],
				ref : 'startIpAddress',
				width : '40%',
				style : 'text-align:center',
				type : 'output'
				, renderer:function(objGrid, nRow, nCol, strValue, objRowData) {
					return ''+ objRowData.startIpAddress +'~'+ objRowData.endIpAddress;
				}
			},
			{
				caption : ['사용여부'],
				ref : 'useYn',
				width : '20%',
				style : 'text-align:center',
				type : 'output'
				, renderer:function(objGrid, nRow, nCol, strValue, objRowData) {
					return strValue === 'Y' ? '사용':'미사용';
				}
			}
		];
	}

	return o;
})();
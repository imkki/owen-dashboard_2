var ocb = {};

ocb.cmm = (function (){
	var cm = {
		version :'1.0.0',
		isTrace : false,
		isDebug : false,
		isError : false
	};
	
	/**
	 * 콘솔 log 콘트롤 isDebug true로 변경후 사용하도록
	 * @param
	 */	
	cm.log = function(){
		if(cm.isDebug){
			console.log.apply(null, arguments);
		}
	};

	cm.errorHandle = function (res){
		if(typeof res === 'undefined' || !res){
			alert('Error');
			return;
		}
	
		if(typeof res.code !== 'undefined'){
			alert("["+ res.code + "] "+ res.message);
			return;
		}else{
			alert('Error');
			return;
		}
	};

	cm.isNull = function (obj){
		return (typeof obj === 'undefined' || obj == null) ? true:false;
	}

	cm.trim = function(str){
		return str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
	}

    /**
     * nvl함수
     * @param pObj 객체
     * @param pDefaultVal null일때 val
     * @param pIsSpaceOpt ''포함여부
     * @returns {*}
     */
    cm.nvl = function (pObj, pDefaultVal, pIsSpaceOpt) {
        const isSpaceConvert = (typeof pIsSpaceOpt === 'undefined') ? false : pIsSpaceOpt;
        if (!isSpaceConvert) {
            return this.isNull(pObj) ? pDefaultVal : pObj;
        } else {
            return (this.isNull(pObj) || pObj === "") ? pDefaultVal : pObj;
        }
    }

	cm.getValue = function (obj){
		return (typeof obj !== 'undefined' && obj) ? obj:'';
	}

	cm.getIntValue = function (obj, defaultVal){
		if(this.isNull(obj)){
			return defaultVal;
		}

		if(typeof obj === 'number'){
			return obj;
		}

		//if(/^(\-|\+)?([0-9]+|Infinity)$/.test(value)){
		//	return Number(value);
		//}
		var parsedVal = parseInt(obj);
		if (isNaN(parsedVal)) {
			return defaultVal;
		}else{
			return parsedVal;
		}
	}

    /**
     * hm문자열을 분으로 변환하는 합수
     * @param pHm '03:45'
     * @returns number 225
     */
    cm.hmToMin = function (pHm) {
        let hm = this.nvl(pHm, '00:00', true);

        if (hm !== '00:00') {
            let times = hm.split(":");

            if (times.length === 2) {
                return this.calcSiBun(times[0], times[1]);
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    /**
     * mnt => hm변환
     * @param mnt
     * @param returnOption
     * @returns {string}
     */
    cm.minToHm = function (mnt, returnOption) {
        let rtVal = "";
        if (isNaN(mnt) || this.isNull(mnt)) return rtVal;

        const signSignal = (mnt >= 0) ? '' : '-';
        const minAbs = Math.abs(mnt);
        let si = Math.floor(minAbs / 60);
        let bun = minAbs % 60;

        if (returnOption === "mnt" || returnOption == "0") {
            rtVal = this.numPad("" + si) + ":" + this.numPad("" + bun);
        } else {
            if (bun === 0) {
                rtVal = si + "시간";
            } else {
                rtVal = si + "시간 " + bun + "분";
            }
        }
        return signSignal + rtVal;
    }

    /**
     * 시/분(hour/mnt) => 분변환 함수
     * @param hour
     * @param mnt
     * @returns number
     */
    cm.calcSiBun = function (hour, mnt) {
        if (isNaN(hour) || isNaN(mnt)) {
            console.log("cmm.calcSiBun :: 잘못된 parameter입니다.(isNaN)");
            return 0;
        }

        let h = (hour) ? Number(hour) : 0;
        let m = (mnt) ? Number(mnt) : 0;

        return h * 60 + m;
    }

    /**
     * 좌측 자리수 문자열채우기
     * @param str 원본
     * @param padLen 채울자리수
     * @param fillStr 채울문자
     * @returns {string|*}
     */
    cm.lpad = function (str, padLen, fillStr) {
        if (!fillStr) {
            if (fillStr.length > padLen) {
                console.log("오류 : 채우고자 하는 문자열이 요청 길이보다 큽니다");
                return str;
            }
        }

        // 시간이 3자리 이상일 경우 처리
        let pLength = (str.length > padLen) ? str.length : padLen;

        str += ""; // 문자변환
        fillStr += ""; // 문자변환

        while (str.length < pLength) {
            str = fillStr + str;
        }
        str = (str.length >= padLen) ? str.substring(0, pLength) : str;
        return str;
    }

    /**
     * 0 으로 패딩
     * @param val 원본문자
     * @param optLen 자리수 기본2
     * @returns {string|*}
     */
    cm.numPad = function (val, optLen) {
        let len = (optLen) ? optLen : 2;
        return this.lpad(val, len, "0");
    }

	/**
	 * 에러 문구 메시지
	 * @param res.code 에러 코드
	 * @param res.message 에러 문구
	 */
	cm.errMsgHandler = function (res) {
		if (res.code === "COM.ERR_1001.400") {
			alert("조회 필수 값이 누락되어 조회에 실패하였습니다."); return;
		} if (res.code === "COM.LGN_0401.401") {
			alert("로그아웃 처리되어, 로그인 후 다시 진행해주시기 바랍니다."); return;
		} else if (res.code === "COM.ERR_4005.403") {
			alert("해당화면을 조회하실 수 있는 권한이 없습니다. 관리자에게 문의바랍니다."); return;
		} else if (res.code === "COM.ERR_4007.404") {
			alert("찾을 수 없는 페이지 입니다. 관리자에게 문의바랍니다."); return;
		} else if (res.code === "COM.ERR_9000.500") {
			alert("서비스에 접속할 수 없습니다. 관리자에게 문의바랍니다."); return;
		}
	}

	cm.getLanguagesList = function(G_msg, val) {
		let text = '';
		switch(val){
			case 'ko':
				text = G_msg.langCd.ko;
				break;
			case 'en':
				text = G_msg.langCd.en;
				break;
			case 'jp':
				text = G_msg.langCd.jp;
				break;
			default:
				break;
		}
		return text;
	}

	cm.getMainNm = function(G_msg, val) {
		//console.log("test ? " + G_msg.mainY);
		let text = '';
		switch(val){
			case 'Y':
				text = G_msg.mainY;//"주";//G_msg.mainY;
				break;
			case 'N':
				text = G_msg.mainN;//"부"//G_msg.mainN;
				break;
			default:
				break;
		}
		return text;
	}

	// 사용 / 미사용
	cm.formatUseYnText = function(val) {
		return val === 'Y' ? message.springMsg.useY : message.springMsg.useN;
	}

	// 표시 / 미표시
	cm.formatDspYnText = function(val) {
		return val === 'Y' ? message.springMsg.dspY : message.springMsg.dspN;
	}

	// 부서 유형 TEXT
	cm.formatDeptGbCdText = function(val) {
		let text = '';
		switch(val){
			case 'DEPT':
				text = message.springMsg.deptGbCd.dept;
				break;
			case 'TEAM':
				text = message.springMsg.deptGbCd.team;
				break;
			case 'WRKTM':
				text = message.springMsg.deptGbCd.wrktm;
				break;
			case 'WRKPS':
				text = message.springMsg.deptGbCd.wrkps;
				break;
			default:
				break;
		}
		return text;
	}

	/**
	 *  Emp 정보 조회
	 * 	@return empInfo 사원정보
	 */
	cm.getMyEmpInfo = function(){
		let empInfo = {};
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/cmmn/mylogin/info/get', JSON.stringify({}), 'application/json', true, function(res) {
			empInfo = res.data;
		}, function(res){
			alert(message.springMsg.alertMsgFailMyEmpInfo);
		});
		return empInfo;
	}

	cm.getGridPagingParam = function(girdId) {
		let page = girdId.getSelectPageIndex();
		let pageSize = girdId.getPageSize();
		let offset = (page - 1) * pageSize;
		//console.log( "page >>> " + page, "pageSize >>> " + pageSize, "offset >>> " + offset);
		return { page : page, pageSize : pageSize, offset : offset };
	}

	cm.getEmpInfo = function(param) {
		var empInfo = {};
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/emp/manage/info/get', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				//console.log("retObj ? ", retObj);
				if (retObj) {
					empInfo = retObj;
				}
			} else {
				alert('회사 목록을 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return {"empInfo" : empInfo};
	}

	cm.getCmpnyList = function(param) {
		//param.useYn = "Y";
		let cmpnyList = [];
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/company/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				//console.log("retObj ? ", retObj);
				if (retObj) {
					cmpnyList = retObj;
				}
			} else {
				alert('회사 목록을 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return {"cmpnyList" : cmpnyList};
	}

	cm.getDeptList = function(param){
		let deptList = [];
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				//console.log("retObj ? ", retObj);
				if (retObj) {
					deptList = retObj;
				}
			} else {
				alert('부서 목록을 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return {"deptList" : deptList};
	}

	cm.getJobTitle = function(param) {
		param.useYn = "Y";
		var value = "";
		var text = "전체";
		let jdTxtData = [];
		let jtTxtData = [];

		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/jobtitle/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if( res.code === 'OK' ){
				let retObj = res.data;
				if (retObj) {
					jdTxtData = retObj.filter(function(ele){
						if (ele.gbCd === 'JD') {
							return  ele;
						}
					});

					jtTxtData = retObj.filter(function(ele){
						if (ele.gbCd === 'JT') {
							return  ele;
						}
					});

					jdTxtData.unshift({"value" : "", "text" : "", "label" : "", "cmpnyId": "", "gbCd": "", "insertDt": "", "insertId": "", "rspofcId": value, "rspofcNm": text, "sortSn": "", "updateDt": "", "updateId": "", "useYn": ""});
					jtTxtData.unshift({"value" : "", "text" : "", "label" : "", "cmpnyId": "", "gbCd": "", "insertDt": "", "insertId": "", "rspofcId": value, "rspofcNm": text, "sortSn": "", "updateDt": "", "updateId": "", "useYn": ""});

					jdTxtData.forEach(function(ele){
						ele.value = ''+ ele.rspofcNm;
						ele.text = ''+ ele.rspofcNm;
						ele.label = ele.rspofcNm ? ''+ ele.rspofcNm:'';
					});

					jtTxtData.forEach(function(ele){
						ele.value = ''+ ele.rspofcNm;
						ele.text = ''+ ele.rspofcNm;
						ele.label = ele.rspofcNm ? ''+ ele.rspofcNm:'';
					});
				}
			} else {
				alert('직위 직책을 조회하는데 실패하였습니다.');
			}
		}, function(res){
			alert(res.message);
		});
		return {"jtTxtData" : jtTxtData, "jdTxtData" : jdTxtData};
	}

	/**
	 * 내 회사정보 조회
	 * MASTER - grp정보 index 0 + 모든회사 list 출력
	 * ADMIN - 현재 로그인 회사만 출력
	 * @return myCmpnyList 내 회사정보 리스트
	 */
	cm.getMyCmpnyList = function(){
		let myCmpnyList = [];
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/cmmn/mylogin/admin/myCmpnyList', JSON.stringify({}), 'application/json', true, function(res) { // success callback
			myCmpnyList = res.data;
		}, function(res){
			alert(message.springMsg.alertMsgFailMyCmpnyList);
		});
		return myCmpnyList;
	}

	/**
	 * 공통코드 조회 - 리스트
	 * @param upperCd(상위코드)
	 * @return
	 */
	cm.getCmmnList = function( upperCd ){
		let cmmnList = [];
		let param = { upperCd : upperCd }
		let _upperCd = upperCd;
		ocb.restcli.exchangeSync('POST', page_context_path + '/rest/cmmn/cmmncode/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			cmmnList = res.data;
		}, function(res){
			alert('[' + _upperCd + ']' + ' 정보를 불러오는데 실패하였습니다.');	// @TODO :: 다국어
		});
		return cmmnList;
	}

	return cm;
})();


var printTrace = function(){
	if(ocb.cmm.isTrace && ocb.cmm.isTrace === true){
		console.log.apply(null, arguments);
	}
}

var printDebug = function(){
	if(ocb.cmm.isDebug && ocb.cmm.isDebug === true){
		console.log.apply(null, arguments);
	}
}

var printError = function(){
	if(ocb.cmm.isError && ocb.cmm.isError === true){
		console.log.apply(null, arguments);
	}
}
/*
 * grid paging ui select ui 만드는 function
 * @param gridObj (window.onload시 gridObject를 넣어주면 됩니다)
 * @return x
 * gridObj.bind("afterrebuild" , "appendGridPageUI");
 * gridObj.bind("afterrefresh" , "appendGridPageUI");
 * gridObj.bind("afterpagechanged" , "appendGridPageUI");
 * 위와 같이 bind해주지 않으면 페이지를 바꿀 때 내부적으로 다시 그리기 떄문에 customevent를 bind해주셔야 됩니다.
 * */
var appendGridPageUI = function (arg) {
	if(arg.data != undefined) {
		//이벤트 객체에서 그리드 객체를 찾아서 파라미터 값을 이벤트 객체의 그리드 객체로 정의합니다.
		arg = arg.data.target
	}
	var pageIdx = arg.getPageIndex();
	var newSelect = document.createElement("select");
	newSelect.setAttribute("class" , "sbgrid-paging-select");
	
	//보여줄 수만큼 정해서 array에 담아두면 됩니다
	var arr = [5 , 10 , 15 , 20]
	for(var i = 0 ; i < arr.length; i+=1) {
		var option = document.createElement('option');
		option.value = arr[i];
		if(arg.getPageSize() == arr[i]) {
			option.selected = true
		}
		option.text = arr[i];
		newSelect.add(option , null)
	}
	//css 수정을 위해 label로 만듬
	var text = document.createElement("label");
	text.setAttribute('class' , 'pagingLbl');
	text.innerText = "개 씩 보기";
	document.querySelector('.sbgrid_PUI_PN,sbgrid_PUI_PN_st').appendChild(newSelect)
	document.querySelector('.sbgrid_PUI_PN,sbgrid_PUI_PN_st').appendChild(text)
	document.querySelector('.sbgrid-paging-select').addEventListener('change' , function() {
		var size = Number(this.value);
		var fixedHeight = arg.getFixedRows();
		var rowHeight = arg.getRowHeight(fixedHeight+1);
		
		arg.setPageSize(size);
		//fixedrowheight , rowheight 설정하지 않았을 때 기본 높이 53px + (row갯수 * row높이) + (caption갯수 * 캡션높이30 고정해주셔야 됩니다.)
		document.querySelector("#"+arg.getParentID()).style.height = (53 + (size * rowHeight) + (fixedHeight * 30))+"px";
		
		arg.rebuild();
		arg.movePaging(pageIdx);
	})
}

ocb.preloader = (function(){
	var loading = {
		isLoaded : false,
		activeCount : 0
	};

	loading.show = function(){
		var _this = this;
		
		++ _this.activeCount;
		printTrace('>>> loading.show() :: activeCount=['+ _this.activeCount +'] ');
		if(_this.activeCount > 1){
			return;
		}

		if(_this.isLoaded){
			return;
		}

		try{
			//$('#ocbViewloading').css("display", "block");

			SBUxMethod.openProgress({modelNm : 'ocbpreloader',  opacity : '0.3'});
			printTrace('>>> loading.show() :::@@ ');
		} catch (e) {
			console.log('>>> loading.show() Error ::'+ e);
		}
		_this.isLoaded = true;
	}

	loading.hide = function(){
		var _this = this;
		if(_this.activeCount > 0){
			-- _this.activeCount;
		}
		printTrace('>>> loading.hide() :: activeCount=['+ _this.activeCount +'] ');
		if(_this.activeCount > 0){
			return;
		}

		if(_this.isLoaded == false){
			return;
		}

		try{
			printTrace('>>> loading.hide() :::@ ');
			setTimeout(function() {
			 	//$('#ocbViewloading').css("display", "none");;
				SBUxMethod.closeProgress({modelNm : 'ocbpreloader',  opacity : '0.1'});
			 	printTrace('>>> loading.hide() :::@ ');
			}, 10);
		} catch (e) {
			printTrace('>>> loading.hide() Error ::'+ e);
		}
		this.isLoaded = false;
	}

	return loading;
})();
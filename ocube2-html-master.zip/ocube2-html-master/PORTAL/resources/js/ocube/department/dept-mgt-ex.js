var deptMgtEx = (function (tabId){
	let dp = {};
	dp.sb_tabDept  = [];
	dp.sb_useYn = [
		{ text : message.springMsg.all, value : "" },
		{ text : message.springMsg.useY, value : "Y" },
		{ text : message.springMsg.useN, value : "N" }
	];

	// 부서 유형 (구분 코드)
	dp.sb_gbCd = [
		{ text : message.springMsg.deptGbCd.dept, value : "DEPT" },
		{ text : message.springMsg.deptGbCd.dept, value : "TEAM" },
		{ text : message.springMsg.deptGbCd.dept, value : "WRKTM" },
		{ text : message.springMsg.deptGbCd.dept, value : "WRKPS" }
	];

	//dp.sb_clsfList = [];		// 직위
	dp.sb_rspofcList = [];		// 직책
	dp.sb_cmpnyList = [];
	dp.sb_deptList = [];
	dp.sb_autoDeptList = [];

	dp.deptNmGridId;		// 부서 이름 그리드
	dp.deptNmGridProperties = {};
	dp.sb_deptNmGridData = [];

	dp.deptEmpGridId;		// 부서원 목록 그리드
	dp.deptEmpGridProperties = {};
	dp.sb_deptEmpGridData = [];

	dp.modalEmpGridId;	// Modal Grid
	dp.modalEmpGridProperties = {};
	dp.sb_modalEmpGridData = [];

	dp.modalSelEmpGridId;
	dp.modalSelEmpGridProperties = {};
	dp.sb_modalSelEmpGridData = []

	dp.modalExcelGridId;
	dp.modalExcelGridProperties = {};
	dp.sb_modalExcelGridData = [];

	let isMaster = false;	// true : MASTER, false : ADMIN
	let g_msg;				// properties msg
	let g_c_msg = message.springMsg;	// 공통 properties msg
	let g_selDeptId = '';	// 조직도에서 선택한 부서 deptId

	// 검색 조건
	let g_schCmpnyId = '';
	let g_schUseYn = '';
	let g_schDeptNm = '';

	let g_useLangList = [];

	dp.init = function(globalOpt){
		g_msg = globalOpt.springMsg;

		let g_empInfo = ocb.cmm.getMyEmpInfo();	// emp 정보 조회
		isMaster = g_empInfo.master;
		g_schCmpnyId = g_empInfo.cmpnyId;

		if(isMaster){
			$('#selectCmpnyListArea').show();
			$('#cmpnyAdminArea').hide();
		}else{
			$('#selectCmpnyListArea').hide();
			$('#cmpnyAdminArea').show();
		}
		$('#deptDetailTdArea').css('visibility', 'hidden');

		// tab 다국어 설정
		dp.sb_tabDept.push({ "id" : "0", "pid" : "-1", "order" : "1", "text" : g_msg.tab.deptInfo, "targetid" : "deptInfo" });
		dp.sb_tabDept.push({ "id" : "1", "pid" : "-1", "order" : "2", "text" : g_msg.tab.deptMember, "targetid" : "deptEmpInfo" });
		SBUxMethod.refresh('tab_dept');

		dp.sb_gbCd.push();

		renderComp(this);
		initDataLoad(this);
	}

	let renderComp = function(obj){
		createDeptNmGrid();
	}

	let initDataLoad = function(obj){
		let myCmpnyList = ocb.cmm.getMyCmpnyList();	// 내 회사정보
		if(isMaster) {
			myCmpnyList.splice(0, 1);	// 첫번째는 그룹이기 때문에 제외

			dp.sb_cmpnyList = [];	// 목록 초기화
			myCmpnyList.forEach(function(ele){
				let selectObj = { text : ele.cmpnyNm, value : ele.cmpnyId };
				dp.sb_cmpnyList.push($.extend(true, {}, selectObj));
			});
			SBUxMethod.refresh('select_cmpny');
			g_schCmpnyId = dp.sb_cmpnyList[0].value;

			let deptParam = {};
			deptParam.cmpnyId = g_schCmpnyId;
			getDeptList(deptParam);
		}else{
			$('#cmpnyAdminArea').html(': &nbsp;&nbsp;' + myCmpnyList[0].cmpnyNm);
		}

		g_useLangList = ocb.cmm.getCmmnList('env.lang');	// 사용언어

		// 부서 이름 Grid
		setDeptNmGridData();
		dp.deptNmGridId.refresh();
	}

	// [API] 부서 조회
	let getDeptList = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let retList = res.data;
			dp.sb_deptList = [];
			dp.sb_autoDeptList = [];
			//sb_deptList.push({ "id" : cmpnyId, "pid" : "-1", "order" : "0", "text" : cmpnyNm });	// @TODO:: 원래대로 하는게 나은건지...

			dp.sb_deptList = retList;
			//sb_autoDeptList.push({ "value" : SBUxMethod.getValue('select_cmpny'), "label" : SBUxMethod.getText('select_cmpny') });
			dp.sb_deptList.forEach(function(ele){
				//let upperId = ele.upperDeptId === '' ? cmpnyId : ele.upperDeptId;	// 최상위 부서일 경우 upperId -> 회사
				//let formatDeptObj = { "id" : ele.deptId, "pid" : upperId, "order" : ele.sortSn, "text" : ele.deptNm };
				//let formatAutoDeptObj = { "value" : ele.deptId, "label" : ele.deptNm }
				let formatAutoDeptObj = { "value" : ele.id, "label" : ele.text }
				//sb_deptList.push($.extend(true, {}, formatDeptObj));
				dp.sb_autoDeptList.push($.extend(true, {}, formatAutoDeptObj));
			});
			dp.sb_deptList.unshift({ "id" : 'ROOT', "pid" : "-1", "order" : "0", "text" : SBUxMethod.getText('select_cmpny') });	// 최상위 -> 회사
			SBUxMethod.refresh('tree_dept');
			SBUxMethod.refresh('input_upperDeptId');
			SBUxMethod.refresh('input_schDept');
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailDeptList);
		});
	}

	// [API] 부서 상세 조회
	let getDeptInfo = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/get', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let retObj = res.data;
			setDeptDetailInfo(retObj);	// 부서 상세정보 set
			let empParam = {};
			empParam.cmpnyId =  retObj.cmpnyId;
			empParam.id =  retObj.id;
			getDeptEmpList(empParam);	// 부서원 조회
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailDeptInfo);
		});
	}

	// [API] 부서 추가 및 수정
	let setDeptInfo = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let retList = res.data;
			alert(g_c_msg.alertMsgSave);
			SBUxMethod.enableTab('tab_dept','deptEmpInfo');	// 부서 저장 성공 -> 부서원 추가 가능
			refreshTreeDept();
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_c_msg.alertMsgSaveTitle + ' ' + g_c_msg.alertMsgFailSuffix);
		});
	}

	// [API] 부서 삭제
	let removeDeptList = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/remove', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			alert(g_msg.alertMsgOkDelDept);
			SBUxMethod.attr('tree_dept','uitype','normal');
			SBUxMethod.attr('tree_dept', 'reselectDeselect',false);
			refreshTreeDept();
			$('#deptDetailTdArea').css('visibility', 'hidden');	// 상세 정보 hide
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailDelDept);
		});
	}

	// [API] 부서원 목록 조회
	let getDeptEmpList = function(param){
		let deptId = param.id;
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			dp.sb_deptEmpGridData = res.data;
			if(dp.deptEmpGridId){
				dp.deptEmpGridId.refresh();
				setDeptEmpCntHtml();
				// 부부서일 경우 checkbox disabled 처리
				dp.sb_deptEmpGridData.forEach(function (ele, i){
					if( ele.mainYn === 'Y'){
						dp.deptEmpGridId.setCellDisabled(i+1, 0, i+1, 0, false, false);
					} else {
						dp.deptEmpGridId.setCellDisabled(i+1, 0, i+1, 0, true, true);
					}
				})

				// 삭제된 부서원 트리에도 반영
				dp.sb_deptList.forEach(function(ele){
					if( ele.id === deptId ) {
						ele.empCnt = dp.sb_deptEmpGridData.length;
					}
				})
			}
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailDeptEmpList);
		});
	}

	// [API] 회사 or 부서 매핑되지 않은 사원 목록 조회
	let getAllEmpList = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/emp/deptnotmapped/page/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			let totalCnt = res.data.totalCnt;
			let empList = res.data.list;

			dp.sb_modalEmpGridData = empList;
			dp.modalEmpGridId.setPageTotalCount(totalCnt); // 데이터의 총 건수를 'setPageTotalCount' 메소드에 setting
			dp.modalEmpGridId.refresh();
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailAllEmpList);
		});
	}

	//  [API] 부서원 저장 및 수정
	let setDeptEmpInfoList = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/set', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			alert(g_msg.alertMsgOkAddDeptEmp);
			SBUxMethod.closeModal('modal_deptEmpAdd');
			let empParam = {};
			empParam.cmpnyId = g_schCmpnyId;
			empParam.id = g_selDeptId;
			//console.log("저장 결과 empParam > " , empParam);
			getDeptEmpList(empParam);	// 부서원 다시 조회
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailAddDeptEmp);
		});
	}

	//  [API] 부서원 삭제
	let removeDeptEmpInfo = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/department/manage/info/employee/remove', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			alert(g_msg.alertMsgOkDelDeptEmp);
			let empParam = {};
			empParam.cmpnyId = g_schCmpnyId;
			empParam.id = g_selDeptId;
			getDeptEmpList(empParam);	// 부서원 다시 조회
		}, function(res){
			//ocb.cmm.errMsgHandler(res);
			alert(g_msg.alertMsgFailDelDeptEmp);
		});
	}

	let setDeptDetailInfo = function(selDeptObj){
		let cmpnyNm = dp.sb_cmpnyList.find(function(e){return e.value === g_schCmpnyId}).text;
		let upperDeptNm = '';
		if( selDeptObj && selDeptObj.pid !== 'ROOT'){
			let upperObj = dp.sb_deptList.find(function (ele){	// 상위 부서 obj
				return ele.id === selDeptObj.pid;
			});
			if(upperObj){ upperDeptNm = upperObj.text; }
		}
		let gbCd = selDeptObj && selDeptObj.gbCd ? selDeptObj.gbCd : 'DEPT';
		let deptNmAbrv = selDeptObj && selDeptObj.deptNmAbrv ? selDeptObj.deptNmAbrv : '';
		let useYn = selDeptObj && selDeptObj.useYn ? selDeptObj.useYn : 'Y';
		let dspYn = selDeptObj && selDeptObj.dspYn ? selDeptObj.dspYn : 'Y';
		let sortSn = selDeptObj && selDeptObj.order ? selDeptObj.order : 1;


		$('#input_cmpnyNm').text(cmpnyNm);
		SBUxMethod.set('select_gbCd', gbCd);
		SBUxMethod.set('input_upperDeptId', upperDeptNm);
		SBUxMethod.set('input_deptNmAbrv', deptNmAbrv);
		SBUxMethod.set('radio_useYn', useYn);
		SBUxMethod.set('radio_dspYn', dspYn);
		SBUxMethod.set('input_sortSn', sortSn);

		if( selDeptObj && selDeptObj.deptLangList && selDeptObj.deptLangList.length > 0 ){
			dp.sb_deptNmGridData = selDeptObj.deptLangList;
			SBUxMethod.show('btn_cmpnyRemove');
		}else{
			setDeptNmGridData();
			SBUxMethod.hide('btn_cmpnyRemove');
		}
		dp.deptNmGridId.refresh();
	}

	let getDeptDetailInfo = function(){
		// 필수값 체크
		let gbCd = SBUxMethod.get('select_gbCd');
		if( !gbCd ) {
			alert(g_msg.alertMsgGbCdRequired);
			SBUxMethod.focus('select_gbCd');
			return false;
		}

		let deptLangList = dp.deptNmGridId.getGridDataAll();
		let chkNmObj = deptLangList.find(function(ele){
			return ele.deptNm === "";
		});
		if( chkNmObj ) {
			//alert('부서명' + '(' + ocb.cmm.getLanguagesList(g_c_msg, chkNmObj.langCd) + ')을 입력해 주세요.');
			alert(g_msg.alertMsgDeptNmRequired);
			return false;
		}

		let upperDeptNm = SBUxMethod.get('input_upperDeptId').trim();
		let upperObj = dp.sb_deptList.find(function (ele){ return ele.text === upperDeptNm; })// @TODO::중복값 체크해야함
		if( !upperObj && upperDeptNm !== '' ) {
			alert(g_msg.alertMsgUpperDeptNmValid)
			SBUxMethod.set('input_upperDeptId', '');
			SBUxMethod.focus('input_upperDeptId');
			return;
		}

		let upperDeptId = upperDeptNm === '' ? 'ROOT' : upperObj.id;	// 빈칸이면 최상위 부서
		let nmObj = deptLangList.find(function(ele){
			return ele.langCd === 'ko';
		});
		let deptNm = nmObj ? nmObj.deptNm : '';	// 한글로
		let deptNmAbrv = SBUxMethod.get('input_deptNmAbrv').trim();
		let useYn = SBUxMethod.get('radio_useYn');
		let dspYn = SBUxMethod.get('radio_dspYn');
		let sortSn = SBUxMethod.get('input_sortSn');
		let cmpnyId = g_schCmpnyId;

		if(confirm('부서정보를 저장하시겠습니까?')) {
			let param = {};
			if (g_selDeptId !== '') {
				param.id = g_selDeptId
			}
			param.cmpnyId = cmpnyId;
			param.text = deptNm;	//deptNm
			param.deptNmAbrv = deptNmAbrv;
			param.pid = upperDeptId;
			// param.deptCd = '1002';		// 입력받지 않음
			param.gbCd = gbCd;
			param.dspYn = dspYn;
			param.useYn = useYn;
			param.delYn = 'N';
			param.order = sortSn ? Number(sortSn) : 1;
			param.deptLangList = deptLangList;
			//console.log("insert >>> param @@@ " , param);
			setDeptInfo(param);
		}
	}

	let modalEmpGridRowDbClickEvt = function(){
		let nRow = dp.modalEmpGridId.getRow();
		let obj = dp.modalEmpGridId.getRowData(nRow,true);
		obj.chkYn = false;

		let chkObj = dp.sb_modalSelEmpGridData.find(function(f){	// 이미 추가된 사원인지 check
			return f.empId === obj.empId;
		});

		if(chkObj){
			alert('\'' + chkObj.empNm + '(' + chkObj.loginId +')' + '\'' + g_msg.alertMsgExistEmpSuffix);
			return;
		}
		dp.sb_modalSelEmpGridData.push($.extend(true, {}, obj));
		dp.modalSelEmpGridId.refresh();
		modalSelEmpGridCallback();
	}

	let modalEmpGridPagingEvt = function (){
		let pageParam = ocb.cmm.getGridPagingParam(dp.modalEmpGridId);
		pageParam.cmpnyId = g_schCmpnyId;
		getAllEmpList(pageParam);
	}

	// @TODO :: 공통으로 만들면 수정하기
	let createDeptNmGrid = function(){
		dp.deptNmGridProperties.parentid = 'deptNmGridArea';
		dp.deptNmGridProperties.id = 'deptMgtEx.deptNmGridId';
		dp.deptNmGridProperties.jsonref = 'deptMgtEx.sb_deptNmGridData';
		dp.deptNmGridProperties.allowuserresize = false;
		dp.deptNmGridProperties.rowheight = '40';
		dp.deptNmGridProperties.fixedrowheight = '40';
		dp.deptNmGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		dp.deptNmGridProperties.columns = deptNmGridColumns();
		dp.deptNmGridId = _SBGrid.create(dp.deptNmGridProperties);
	};

	let createDeptEmpGrid = function(){
		dp.deptEmpGridProperties.parentid = 'deptEmpGridArea';
		dp.deptEmpGridProperties.id = 'deptMgtEx.deptEmpGridId';
		dp.deptEmpGridProperties.jsonref = 'deptMgtEx.sb_deptEmpGridData';
		dp.deptEmpGridProperties.allowuserresize = false;
		dp.deptEmpGridProperties.rowheight = '40';
		dp.deptEmpGridProperties.fixedrowheight = '40';
		dp.deptEmpGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		dp.deptEmpGridProperties.columns = deptEmpGridColumns();
		dp.deptEmpGridId = _SBGrid.create(dp.deptEmpGridProperties);
	};

	let createModalEmpGrid = function(){
		dp.modalEmpGridProperties.parentid = 'modalEmpListGridArea';
		dp.modalEmpGridProperties.id = 'deptMgtEx.modalEmpGridId';
		dp.modalEmpGridProperties.jsonref = 'deptMgtEx.sb_modalEmpGridData';
		dp.modalEmpGridProperties.allowuserresize = false;
		dp.modalEmpGridProperties.rowheight = '40';
		dp.modalEmpGridProperties.fixedrowheight = '40';
		dp.modalEmpGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		dp.modalEmpGridProperties.paging = { 'type' : 'page', 'count' : 5, 'size' : 10 };	// 페이징 처리
		dp.modalEmpGridProperties.columns = modalEmpGridColumns();
		dp.modalEmpGridId = _SBGrid.create(dp.modalEmpGridProperties);

		dp.modalEmpGridId.bind('dblclick', modalEmpGridRowDbClickEvt);
		dp.modalEmpGridId.bind("beforepagechanged", modalEmpGridPagingEvt);
	};

	let createModalSelEmpGrid = function(){
		dp.modalSelEmpGridProperties.parentid = 'modalSelEmpListGridArea';
		dp.modalSelEmpGridProperties.id = 'deptMgtEx.modalSelEmpGridId';
		dp.modalSelEmpGridProperties.jsonref = 'deptMgtEx.sb_modalSelEmpGridData';
		dp.modalSelEmpGridProperties.allowuserresize = false;
		dp.modalSelEmpGridProperties.rowheight = '40';
		dp.modalSelEmpGridProperties.fixedrowheight = '40';
		dp.modalSelEmpGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		dp.modalSelEmpGridProperties.columns = modalSelEmpGridColumns();
		dp.modalSelEmpGridId = _SBGrid.create(dp.modalSelEmpGridProperties);
	};

	let createModalExcelGrid = function(){
		dp.modalExcelGridProperties.parentid = 'modalExcelGridArea';
		dp.modalExcelGridProperties.id = 'deptMgtEx.modalExcelGridId';
		dp.modalExcelGridProperties.jsonref = 'deptMgtEx.sb_modalExcelGridData';
		dp.modalExcelGridProperties.allowuserresize = false;
		dp.modalExcelGridProperties.rowheight = '40';
		dp.modalExcelGridProperties.fixedrowheight = '40';
		dp.modalExcelGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		dp.modalExcelGridProperties.columns = modalExcelGridColumns();
		dp.modalExcelGridId = _SBGrid.create(dp.modalExcelGridProperties);
	};

	/*let setGridProperties = function(areaId, girdId, gridObj, propertiesObj, gridData, columns, rowHeight){
	}*/

	let deptNmGridColumns = function(){
		return [
			{
				caption : [g_c_msg.gridCol.langCd]
				, ref : 'langCd'
				, width : '30%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function(langCd){
						return ocb.cmm.getLanguagesList(g_c_msg, langCd);
					}
				}
			}
			, {
				caption :  [g_c_msg.gridCol.name]
				, ref : 'deptNm'
				, width : '90%'
				, style : 'text-align:center'
				, type : 'input'
				, typeinfo : {
					maxlength : 30
				}
			}
		];
	}

	let deptEmpGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.gbCd] //['구분']
				, ref : 'mainYn'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (mainYn){
						return ocb.cmm.getMainNm(g_c_msg, mainYn);
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.clsfNm]	// ['직위']
				, ref : 'clsfNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.rspofcNm]
				, ref : 'rspofcNm'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.empNmId]
				, ref : 'empVO'
				, width : '25%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (empVO){
						return empVO.empNm;
					}
				}
			}
		];
	}

	let modalEmpGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.empId]
				, ref : 'empId'
				, width : '30%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.empNm]
				, ref : 'empNm'
				, width : '30%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.id]
				, ref : 'loginId'
				, width : '30%'
				, style : 'text-align:center'
				, type : 'output'
			}
		];
	}

	let modalSelEmpGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.empId]
				, ref : 'empId'
				, width : '18%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.empNm]
				, ref : 'empNm'
				, width : '18%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.id]
				, ref : 'loginId'
				, width : '18%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.clsfNm]
				, ref : 'clsfNm'
				, width : '18%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.rspofcNm]
				, ref : 'rspofcId'
				, width : '18%'
				, style : 'text-align:center'
				, type : 'combo'
				, typeinfo : {
					ref : 'deptMgtEx.sb_rspofcList'
					, label : 'rspofcNm'
					, value : 'rspofcId'
					, displayui : true
					, oneclickedit : true
					, unselect : {
						label : g_c_msg.choise
						, value : ''
					}
				}
			}

		];
	}

	let modalExcelGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '5%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					fixedcellcheckbox : {
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.cmpnyId]
				, ref : 'cmpnyId'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.upperDeptId]
				, ref : 'upperDeptId'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.upperDeptNm]
				, ref : 'upperDeptNm'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.deptGbCd]
				, ref : 'gbCd'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						return ocb.cmm.formatDeptGbCdText(val);
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.deptCd]
				, ref : 'deptCd'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.deptNm]
				, ref : 'deptNm'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.abrv]
				, ref : 'deptNmAbrv'
				, width : '15%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_c_msg.gridCol.useYn]
				, ref : 'useYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						return ocb.cmm.formatUseYnText(val);
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.dspYn]
				, ref : 'dspYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'output'
				, format : {
					type :'custom'
					, callback : function (val){
						return ocb.cmm.formatDspYnText(val);
					}
				}
			}
			, {
				caption : [g_c_msg.gridCol.sortSn]
				, ref : 'sortSn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'output'
			}
		];
	}

	let setDeptNmGridData = function(){
		dp.sb_deptNmGridData = [];
		g_useLangList.forEach(function (ele){
			dp.sb_deptNmGridData.push({langCd: ele.cd, deptNm: ""});
		});
	}

	let setDeptEmpCntHtml = function (){
		let gbCd = SBUxMethod.getText('select_gbCd');
		let deptNm = dp.sb_deptList.find(function(f){ return f.id === g_selDeptId; }).text;
		let cnt = dp.sb_deptEmpGridData.length;
		let deptInfoTxtHtml = '[' + gbCd + '] ' + deptNm + ' 소속 부서원 : <b>총 ' + cnt + '명</b>';	// @TODO :: 수정
		$('#deptInfoTxt').html(deptInfoTxtHtml);
	}

	// tree reload
	let refreshTreeDept = function(){
		let param = {};
		param.cmpnyId = g_schCmpnyId;
		param.useYn = g_schUseYn;
		param.text = g_schDeptNm;
		//console.log("검색 조건 param >>> " , param);
		getDeptList(param);
	}

	// 상단 부서 검색
	dp.fnClickDeptSchBtn = function (){
		$('#deptDetailTdArea').css('visibility', 'hidden'); // 상세 정보 hide

		let cmpnyId = SBUxMethod.getValue('select_cmpny');
		let useYn = SBUxMethod.getValue('select_useYn');
		let deptNm = SBUxMethod.get('input_schDept');

		g_schCmpnyId = cmpnyId ? cmpnyId : '';
		g_schUseYn = useYn ? useYn : '';
		g_schDeptNm = deptNm ? deptNm : '';

		let type = SBUxMethod.getAttr('tree_dept').uitype;
		if( type === 'checkbox' ) {
			SBUxMethod.attr('tree_dept','uitype','normal');
			SBUxMethod.attr('tree_dept', 'reselectDeselect',false);
		}

		refreshTreeDept();
	}

	dp.fnClickTreeDeptList = function(obj){
		SBUxMethod.setTab('tab_dept', 'deptInfo');

		let type = SBUxMethod.getAttr('tree_dept').uitype;
		if(type !== 'normal') { return; }	// 선택삭제 > chkbox 활성화 된 상태에서 트리 클릭했을 때 이벤트 처리 x
		if(obj.id === 'ROOT') { return; }

		$('#deptDetailTdArea').css('visibility', 'visible');
		SBUxMethod.show('btn_deptRemove');

		g_selDeptId = obj.attrObj.id;

		let param = {};
		param.cmpnyId = obj.attrObj.cmpnyId;
		param.id = obj.attrObj.id;	// id -> deptId
		getDeptInfo(param);

		let jobParam = {};
		jobParam.cmpnyId = obj.attrObj.cmpnyId;
		jobParam.gbCd = 'JD';	// JT : 직위, JD : 직책
		dp.sb_rspofcList = ocb.cmm.getJobTitle(jobParam).jdTxtData;	// 직위/직책 조회
		if(dp.modalSelEmpGridId){
			dp.modalSelEmpGridId.rebuild();
		}
		SBUxMethod.enableTab('tab_dept','deptEmpInfo');	// 부서원정보 tab enable
	};

	// 엑셀 업로드 버튼
	dp.fnClickDeptExcelBtn = function(){
		SBUxMethod.openModal('modal_deptExcel');
		if( !dp.modalExcelGridId ) { createModalExcelGrid(); }
	}

	// 부서 추가 버튼
	dp.fnClickDeptAddBtn = function(){
		$('#deptDetailTdArea').css('visibility', 'visible');
		SBUxMethod.hide('btn_deptRemove');

		g_selDeptId = '';
		SBUxMethod.refresh('tree_dept');	// 트리 선택 해제
		SBUxMethod.setTab('tab_dept', 'deptInfo');	// 부서정보 탭으로 이동
		SBUxMethod.disableTab('tab_dept', 'deptEmpInfo');	// 부서원정보 tab disabled

		// 부서정보
		setDeptDetailInfo();

		// 부서원정보
		dp.sb_deptEmpGridData = [];	// 초기화
		dp.deptEmpGridId.refresh();
	}

	dp.fnClickDeptChkRemoveBtn = function(){
		let type = SBUxMethod.getAttr('tree_dept').uitype;
		if( type === 'normal'){
			SBUxMethod.attr('tree_dept','uitype','checkbox');
			SBUxMethod.attr('tree_dept', 'reselectDeselect',true);
		}else{
			let chkDeptList = SBUxMethod.get('tree_dept');
			if( chkDeptList.length <= 0 ) {
				alert(g_msg.alertMsgDelDeptSelect);
				return;
			}

			let empChkList = [];
			let removeList = [];

			chkDeptList.forEach(function (ele){
				if( ele.id !== 'ROOT'){		// 회사 제외
					let obj = $.extend(true, {},ele.attrObj);
					if( obj.empCnt > 0 ) { empChkList.push(obj); }

					obj.delYn = 'Y';
					removeList.push(obj);
				}
			})

			if( empChkList.length > 0 ){
				let msg = '';
				let str = ', ';
				empChkList.forEach(function(ele, i){
					if( i === empChkList.length-1 ) { str = ''; }
					msg += '\'' + ele.text + '\'' + str;
				})
				alert(msg + g_msg.alertMsgExistDeptsEmp);
				return;
			}

			if(confirm(g_msg.confirmMsgDelDepts)){
				let param = {};
				param.deptList = removeList;
				// console.log("삭제 param > ", param);
				removeDeptList(param);
			}
		}
	}

	// 탭 변경 시 Grid Create
	dp.fnClickDeptTab = function (){
		let tagetTab = SBUxMethod.get('tab_dept');
		if( tagetTab === 'deptEmpInfo' ){	// 부서원정보 탭
			if(!dp.deptEmpGridId){
				createDeptEmpGrid();		// 부서원 목록 그리드 생성
			} else {
				dp.deptEmpGridId.refresh();	// @TODO :: 다른 방법 찾으면 적용하기
			}
		} else {
			if(!dp.deptNmGridId){
				createDeptNmGrid();		// 부서 이름 그리드 생성
			} else {
				dp.deptNmGridId.refresh();
			}
		}
	}

	// 부서 저장
	dp.fnClickDeptSaveBtn = function(){
		getDeptDetailInfo();
	}

	// 부서 삭제
	dp.fnClickDeptRemoveBtn = function(){
		/*if(dp.sb_deptEmpGridData.length > 0){
			alert(g_msg.alertMsgExistDeptEmp);
			return;
		}*/
		let removeObj = dp.sb_deptList.find(function (ele) {
			return ele.id === g_selDeptId;
		})

		if( removeObj.empCnt > 0 ){	// 부서원이 존재하는 경우 삭제 불가능
			alert(g_msg.alertMsgExistDeptEmp);
			return;
		}

		if(confirm(g_msg.confirmMsgDelDept)){
			let removeList = [];
			removeList.push({ delYn : 'Y', cmpnyId : SBUxMethod.getValue('select_cmpny'), id : g_selDeptId });

			let param = {};
			param.deptList = removeList;
			removeDeptList(param);
		}
	}

	dp.fnClickDeptEmpAddBtn = function(){
		SBUxMethod.openModal('modal_deptEmpAdd');

		// 그리드 생성
		if( !dp.modalEmpGridId ) { createModalEmpGrid(); }
		if( !dp.modalSelEmpGridId ) { createModalSelEmpGrid(); }

		/* 부서원/추가 Modal */
		let pageParam = ocb.cmm.getGridPagingParam( dp.modalEmpGridId );
		pageParam.cmpnyId = g_schCmpnyId;
		getAllEmpList(pageParam);

		dp.sb_modalSelEmpGridData = [];
		dp.modalSelEmpGridId.refresh();
	}

	dp.fnClickDeptEmpChkRemoveBtn = function(){
		let ckhList = dp.deptEmpGridId.getCheckedRowData(0);
		//console.log("ckhList >> " , ckhList);
		if( ckhList.length <= 0 ) {
			alert(g_msg.alertMsgDelDeptEmpSelect);
			return;
		}

		if(confirm(g_msg.confirmMsgDelDeptEmp)){
			let removeList = [];
			ckhList.forEach(function(ele){
				let obj = $.extend(true, {}, ele.data);
				//let obj = { cmpnyId : ele.data.cmpnyId, deptId : ele.data.deptId, empId : ele.data.empId, delYn : 'Y' }
				obj.delYn = 'Y';
				obj.cmpnyId = ele.data.cmpnyId;
				obj.deptId = ele.data.deptId;
				obj.empId = ele.data.empId;
				obj.clsfId = ele.data.clsfId;
				obj.rspofcId = ele.data.rspofcId;
				obj.mainYn = ele.data.mainYn;
				obj.dlngCd = 'HMOD';	// 처리코드 인사이동:HMOV, 등록변경삭제:HMOD*/

				// 아무 이상 없으면 삭제
				/*obj.deptEmpMapngHistVO = {};
                obj.deptEmpMapngHistVO.cmpnyId = ele.data.cmpnyId;
                obj.deptEmpMapngHistVO.deptId = ele.data.deptId;
                obj.deptEmpMapngHistVO.empId = ele.data.empId;
                //obj.deptEmpMapngHistVO.clsfId = ele.data.clsfId;
                obj.deptEmpMapngHistVO.rspofcId = ele.data.rspofcId;
                obj.deptEmpMapngHistVO.mainYn = ele.data.mainYn;
                obj.deptEmpMapngHistVO.beforeDeptId = ele.data.deptId;
                obj.deptEmpMapngHistVO.beforeClsfId = ele.data.clsfId;
                obj.deptEmpMapngHistVO.beforeRspofcId = ele.data.rspofcId;
                obj.deptEmpMapngHistVO.beforeMainYn = ele.data.mainYn;
                obj.deptEmpMapngHistVO.dlngCd = 'HMOD';	// 처리코드 인사이동:HMOV, 등록변경삭제:HMOD*/
				removeList.push($.extend(true, {}, obj));
			})

			let param = {};	// 임시
			param.deptEmpMapngList = removeList;
			//console.log("삭제 리스트 param >>> " , param);
			removeDeptEmpInfo(param);
		}
	}

	// 전체사원목록 사원명 검색
	dp.fnClickDeptEmpSchBtn = function (){
		let empNm = SBUxMethod.get('input_schDeptEmp');
		//if( typeof empNm === 'undefined') { alert('검색할 사원명을 입력해 주세요.'); }

		let pageParam = ocb.cmm.getGridPagingParam( dp.modalEmpGridId );
		pageParam.cmpnyId = g_schCmpnyId;
		if( empNm ){
			pageParam.empNm = empNm;
		}
		getAllEmpList(pageParam);
	}

	// > Btn 클릭
	dp.fnClickGridDataMoveRight = function(){
		let ckhList = dp.modalEmpGridId.getCheckedRowData(0);
		let dupList = [];

		ckhList.forEach(function(ele, i){
			// ele.chkYn = false;
			let obj = ele.data;
			obj.chkYn = false;

			let chkObj = dp.sb_modalEmpGridData.find(function(f){	// 이미 추가된 사원인지 check
				return f.empId === obj.empId;
			});

			if(chkObj){
				dupList.push($.extend(true, {}, chkObj));
			}else{
				dp.sb_modalEmpGridData.push($.extend(true, {}, obj));
			}
		});

		if(dupList.length > 0) {
			let msg = "";
			let str = ', ';
			dupList.forEach(function(ele, i){
				if( i === dupList.length-1 ) { str = ''; }
				msg += '\'' + ele.empNm + '(' + ele.loginId +')' + '\'' + str;
			});
			alert(msg + g_msg.alertMsgExistEmpSuffix);
		}

		dp.modalSelEmpGridId.refresh();
		modalSelEmpGridCallback();
	}

	let modalSelEmpGridCallback = function(){
		dp.sb_modalEmpGridData.forEach(function (ele, i){
			if( ele.rspofcId ){
				dp.modalSelEmpGridId.setCellDisabled(i+1, 5, i+1, 5, true, true);
				dp.modalSelEmpGridId.setCellStyle('background-color', i+1, 5, i+1, 5, '#e3dde3');
			}
		})
	}

	// < Btn 클릭
	dp.fnClickGridDataMoveLeft = function(){
		let ckhList = dp.modalSelEmpGridId.getCheckedRowData(0);
		let remainList = [];
		dp.sb_modalEmpGridData.forEach(function(ele, i){
			let removeObj = ckhList.find(function(f){
				return ele.empId === f.data.empId;
			});
			if( !removeObj ) { remainList.push($.extend(true, {}, ele)) }//{ dp.sb_modalEmpGridData.splice(i, 1); }	// 선택된 사원목록에서 삭제
		});

		dp.sb_modalEmpGridData = remainList;
		dp.modalSelEmpGridId.refresh();
	}

	dp.fnClickDeptEmpSaveBtn = function(){
		let saveDeptEmpList = dp.modalSelEmpGridId.getGridDataAll();
		if( saveDeptEmpList.length <= 0 ) {
			alert(g_msg.alertMsgAddDeptEmpSelect);
			return;
		}

		let addList = [];
		let mainYn = 'Y'; // 부서/팀 관리 화면에서는 주부서만 추가 가능
		let cmpnyId = g_schCmpnyId;

		saveDeptEmpList.forEach(function(ele){
			let obj = {};
			obj.cmpnyId = cmpnyId; //ele.cmpnyId;
			obj.deptId = g_selDeptId; //ele.deptId;
			obj.empId = ele.empId;
			obj.rspofcId = ele.rspofcId ? ele.rspofcId : '';
			obj.clsfId = ele.clsfId;			// beforeClsfId 여기에 매핑돼서 추가
			obj.mainYn = mainYn;
			obj.delYn = 'N';
			obj.sortSn = 1; //ele.sortSn;		//@TODO :: 임시값 수정
			obj.dlngCd = 'HMOD';	// 처리코드 인사이동:HMOV, 등록변경삭제:HMOD
			obj.deptEmpMapngHistVO = {};
			//obj.deptEmpMapngHistVO.cmpnyId = cmpnyId; // ele.data.cmpnyId;
			//obj.deptEmpMapngHistVO.deptId = g_selDeptId;//ele.data.deptId;
			//obj.deptEmpMapngHistVO.empId = ele.empId;
			//obj.deptEmpMapngHistVO.clsfId = ele.clsfId;	// 직위 삭제됨
			//obj.deptEmpMapngHistVO.rspofcId = ele.rspofcId;
			//obj.deptEmpMapngHistVO.mainYn = mainYn;
			//obj.deptEmpMapngHistVO.beforeDeptId = ele.deptId ? ele.deptId : g_selDeptId;
			//obj.deptEmpMapngHistVO.beforeClsfId = ele.clsfId;			// 직위/직책 수정 x -> 그대로 넣어줌
			//obj.deptEmpMapngHistVO.beforeRspofcId = ele.rspofcId;
			//obj.deptEmpMapngHistVO.beforeMainYn = ele.mainYn ? ele.mainYn : mainYn;
			//obj.deptEmpMapngHistVO.dlngCd = 'HMOD';	// 처리코드 인사이동:HMOV, 등록변경삭제:HMOD

			addList.push($.extend(true, {}, obj));
		});

		let param = {};	// 임시
		param.deptEmpMapngList = addList;
		//console.log("저장 리스트 param >>> " , param);

		setDeptEmpInfoList(param);
	}
	return dp;
})();
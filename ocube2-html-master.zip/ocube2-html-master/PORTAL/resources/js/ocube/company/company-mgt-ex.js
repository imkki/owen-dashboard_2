var companyMgtEx = (function(){
	let cp = {};

	let G_MASTER_CODE = 'MASTER';	// 마스터
	let G_ADMIN_CODE = 'ADMIN';		// 관리자
	let g_roleType = G_ADMIN_CODE;

	let g_grpId;
	let g_cmpnyId;

	let g_msg;

	cp.sb_cmpnyList = [];
	cp.sb_useYn = [];
	cp.sb_selUseLangCd = [];
	
	cp.cmpnyGridId;
	cp.cmpnyGridProperties = {};
	cp.sb_cmpnyGridData = {
		"resources": []
	};
	
	cp.cmpnyNmGridId;
	cp.cmpnyNmGridProperties = {};
	cp.sb_cmpnyNmGridData= {
		"resources": []
	};
	
	cp.init = function(globalOpt){
		g_msg = globalOpt.springMsg;

		let g_empInfo = ocb.cmm.getMyEmpInfo();
		g_grpId = g_empInfo.grpId;
		g_cmpnyId = g_empInfo.cmpnyId;
		g_roleType = g_empInfo.master ? G_MASTER_CODE : G_ADMIN_CODE;

		if(g_roleType === G_MASTER_CODE) {
			$('#companyMasterArea').show();
			$('#cmpnyListArea').show();
			SBUxMethod.show('btn_cmpnyRemove');
		}else{
			$('#companyMasterArea').hide();
			$('#cmpnyListArea').hide();
			SBUxMethod.hide('btn_cmpnyRemove');
			$('#cmpnyDetailArea').addClass('page_content_wrap_100').removeClass('page_content_wrap_70 overf_auto');
		}

		$('#cmpnyDetailArea').css('visibility', g_roleType === G_MASTER_CODE ? 'hidden' : 'visible');	// 상세 정보 hide

		cp.sb_useYn = [
			{ text : g_msg.all, value : "" },
			{ text : g_msg.useY, value : "Y" },
			{ text : g_msg.useN, value : "N" }
		];
		SBUxMethod.refresh('select_useYn');

		cp.sb_selUseLangCd = [
			{ text : g_msg.langCd.kr, value : "kr" },
			{ text : g_msg.langCd.en, value : "en" },
		];
		SBUxMethod.refresh('select_useLangCd');

		renderComp(this);
		attachEvent(this);
		initDataLoad(this);
	}

	let renderComp = function(obj){
		if(g_roleType === G_MASTER_CODE){
			createCmpnyListGrid();	// GRID 생성
		}
		createCmpnyNmGrid();	// 상세 정보 회사명 GRID 생성
	}

	let attachEvent = function(obj){
		let clickCmpnyGridRowEvt = function(){
			let selIndex = cp.cmpnyGridId.getRow();
			if( selIndex <= 0 ) { return; }

			let selData = cp.cmpnyGridId.getRowData(selIndex);

			$("#cmpnyDetailArea").css('visibility', 'visible');
			
			setCmpnyDetailInfo(selData);
			SBUxMethod.show('btn_cmpnyRemove');
		}
		
		if( cp.cmpnyGridId ) {
			cp.cmpnyGridId.bind('click', clickCmpnyGridRowEvt);	// event bind
		}
	}

	let initDataLoad = function(obj){
		let param = {};
		if(g_roleType === G_MASTER_CODE){	// 마스터 권한
			getSelectboxCompanyList(param);	// 검색 selectbox
			getGridCompanyList(param);		// 회사목록 grid
		}else{	// 관리자 권한
			param.cmpnyId = g_cmpnyId;
			getCompanyInfo(param, function(res){
				setCmpnyDetailInfo( res.data );	// 회사 상세정보 세팅
			}, function(res){
				ocb.cmm.errMsgHandler(res);
				alert('회사 정보를 불러오는데 실패하였습니다.');
			});
		}
	}
	
	// 회사명 selectbox 조회
	let getSelectboxCompanyList = function(param){
		getCompanyList(param, function(res){
			let retList = res.data;
			cp.sb_cmpnyList = [];	// 목록 초기화
			cp.sb_cmpnyList.push({ text : g_msg.all, value : "" });

			retList.forEach(function(ele){
				let selectObj = { text : ele.cmpnyNm, value : ele.cmpnyId };
				cp.sb_cmpnyList.push($.extend(true, {}, selectObj));
			});
			SBUxMethod.refresh('select_cmpny');
		}, function(res){
			ocb.cmm.errMsgHandler(res);	// 서버에서 RestResponseVO.fail 일 경우 추가해주면 좋을 것 같은데..
			alert('회사 목록을 조회하는데 실패하였습니다.');
		});
	}
	
	// 회사 목록 Grid 조회
	let getGridCompanyList = function(param){
		getCompanyList(param, function(res){
			cp.sb_cmpnyGridData.resources = res.data;	// Grid Data 변경
			cp.cmpnyGridId.refresh();
		}, function(res){
			ocb.cmm.errMsgHandler(res);
			alert('회사 목록을 조회하는데 실패하였습니다.');
		});
	}

	// [API] 회사 목록 조회 - 마스터
	let getCompanyList = function(param, fnSucCallback, fnErrCallback){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/company/manage/info/list', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if(fnSucCallback){
				fnSucCallback.call(this, res);
			}
        }, function(res){
			if(fnErrCallback){
                fnErrCallback.call(this, res);
            }
		});
	}
	
	// [API] 회사 정보 조회
	let getCompanyInfo = function(param, fnSucCallback, fnErrCallback){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/company/manage/info/get', JSON.stringify(param), 'application/json', true, function(res) { // success callback
			if(fnSucCallback){
				fnSucCallback.call(this, res);
			}
		}, function(res){
			if(fnErrCallback){
				fnErrCallback.call(this, res);
			}
		});
	}

	// 디테일 정보 세팅
	let setCmpnyDetailInfo = function( selCmpnyObj ){	// selCmpny 존재하면 EDIT, 존재하지 않으면 NEW
		let obj = selCmpnyObj;
		if( !obj ) { cp.cmpnyGridId.setRow(-1); } // 선택 해제

		SBUxMethod.set('input_cmpnyCd', obj ? obj.cmpnyCd : "");
		SBUxMethod.set('radio_useYn', obj ? obj.useYn : "Y");
		SBUxMethod.set('input_cmpnyNmAbrv', obj ? obj.cmpnyNmAbrv : "");
		SBUxMethod.set('input_webConectAddr', obj ? obj.webConectAddr : "");
		SBUxMethod.set('input_emailDomn', obj ? obj.emailDomn : "");
		SBUxMethod.set('input_telno1', obj ? obj.telno1 : "");
		SBUxMethod.set('input_webSj', obj ? obj.webSj : "");
		SBUxMethod.set('select_useLangCd', obj ? obj.useLangCd : "kr");
		SBUxMethod.set('input_cmpnyAddr', obj ? obj.cmpnyAddr : "");
		SBUxMethod.set('input_cmpnyDtlAddr', obj ? obj.cmpnyDtlAddr : "");
		SBUxMethod.set('input_cmpnyZipcd', obj ? obj.cmpnyZipcd : "");
		SBUxMethod.set('input_sortSn', obj ? obj.sortSn : 0);
		SBUxMethod.set('radio_smtpSvrUseYn', obj ? obj.smtpSvrUseYn : "N");
		SBUxMethod.set('input_trnsmrEmailAddr', obj ? obj.trnsmrEmailAddr : "");
		SBUxMethod.set('input_smtpSvrDomn', obj ? obj.smtpSvrDomn : "");
		SBUxMethod.set('input_smtpId', obj ? obj.smtpId : "");
		SBUxMethod.set('input_trnsmrNm', obj ? obj.trnsmrNm : "");
		SBUxMethod.set('input_smtpPortNo', obj ? obj.smtpPortNo : "");
		SBUxMethod.set('input_smtpPwd', obj ? obj.smtpPwd : "");
		
		if( obj ){
			cp.sb_cmpnyNmGridData.resources = obj.cmpnyNmLangList;
		}else{
			cp.sb_cmpnyNmGridData.resources = [];
			cp.sb_cmpnyNmGridData.resources.push({langCd: "kr", cmpnyNm: ""});
			cp.sb_cmpnyNmGridData.resources.push({langCd: "en", cmpnyNm: ""});
		}
		cp.cmpnyNmGridId.refresh();
		
		setSmtpUseAreaHiddenYn(obj ? obj.smtpSvrUseYn === "N" : true );
	}

	let getCmpnyDetailInfo = function(){
		// 필수값 체크
		let cmpnyCd = SBUxMethod.get('input_cmpnyCd');
		if( !cmpnyCd ) {
			alert('회사코드를 입력해 주세요.');
			SBUxMethod.focus('input_cmpnyCd');
			return false;
		}

		let useYn = SBUxMethod.get('radio_useYn');
		if( !useYn ) {
			alert('사용여부를 선택해 주세요.');
			return false;
		}

		let cmpnyNmLangList = cp.cmpnyNmGridId.getGridDataAll();
		let chkNmObj = cmpnyNmLangList.find(function(ele){
			return ele.cmpnyNm === "";
		});
		if( chkNmObj ) {
			alert('회사명' + '(' + formatCmpnyNmLangText(chkNmObj.langCd) + ')을 입력해 주세요.');
			return false;
		}

		let useLangCd = SBUxMethod.get('select_useLangCd');
		if( !cmpnyCd ) {
			alert('사용언어를 선택해 주세요.');
			SBUxMethod.focus('select_useLangCd');
			return false;
		}

		let cmpnyNmAbrv = SBUxMethod.get('input_cmpnyNmAbrv');
		if( !cmpnyNmAbrv ) {
			alert('회사명 약어를 입력해 주세요.');
			SBUxMethod.focus('input_cmpnyNmAbrv');
			return false;
		}

		let smtpSvrUseYn = SBUxMethod.get('radio_smtpSvrUseYn');

		let trnsmrEmailAddr = SBUxMethod.get('input_trnsmrEmailAddr');
		let trnsmrNm = SBUxMethod.get('input_trnsmrNm');
		let smtpSvrDomn = SBUxMethod.get('input_smtpSvrDomn');
		let smtpPortNo = SBUxMethod.get('input_smtpPortNo');
		let smtpId = SBUxMethod.get('input_smtpId');
		let smtpPwd = SBUxMethod.get('input_smtpPwd');

		if( smtpSvrUseYn === 'Y' ) {	// SMTP 사용일 때 필수값 체크
			if( !trnsmrEmailAddr ) {
				alert('관리 이메일을 입력해 주세요.');
				SBUxMethod.focus('input_trnsmrEmailAddr');
				return false;
			}

			if( !trnsmrNm ) {
				alert('발신자명을 입력해 주세요.');
				SBUxMethod.focus('input_trnsmrNm');
				return false;
			}
	
			if( !smtpSvrDomn ) {
				alert('SMTP 서버를 입력해 주세요.');
				SBUxMethod.focus('input_smtpSvrDomn');
				return false;
			}

			if( !smtpPortNo ) {
				alert('SMTP 포트를 입력해 주세요.');
				SBUxMethod.focus('input_smtpPortNo');
				return false;
			}

			if( !smtpId ) {
				alert('SMTP 아이디를 입력해 주세요.');
				SBUxMethod.focus('input_smtpId');
				return false;
			}

			if( !smtpPwd ) {
				alert('SMTP 비밀번호를 입력해 주세요.');
				SBUxMethod.focus('input_smtpPwd');
				return false;
			}
		}

		if( !confirm("저장하시겠습니까?") ){ return false; }
		
		let webConectAddr = SBUxMethod.get('input_webConectAddr');
		let emailDomn = SBUxMethod.get('input_emailDomn');
		let telno1 = SBUxMethod.get('input_telno1');
		let webSj = SBUxMethod.get('input_webSj');				
		let cmpnyAddr = SBUxMethod.get('input_cmpnyAddr');
		let cmpnyDtlAddr = SBUxMethod.get('input_cmpnyDtlAddr');
		let cmpnyZipcd = SBUxMethod.get('input_cmpnyZipcd');
		let sortSn = SBUxMethod.get('input_sortSn');	

		let nmObj = cmpnyNmLangList.find(function(ele){
			return ele.langCd === useLangCd; // 사용하는 언어에 맞춰서 회사 이름 넣어줌
		});
		let cmpnyNm = nmObj ? nmObj.cmpnyNm : ''; 	
		
		let cmpnyId = '';	// @TODO :: 서버에서 ID 임의 생성 시 cmpnyId === '' 일 때도 체크해야함

		if(g_roleType === G_MASTER_CODE) {	// 마스터 - 추가, 수정 가능
			let selIdx = cp.cmpnyGridId.getRow();
			if(selIdx > 0) { // 수정일 때
				cmpnyId = cp.cmpnyGridId.getRowData(selIdx).cmpnyId;
			}
		}

		let param = {};
		param.grpId = g_grpId;
		param.cmpnyId = cmpnyId;
		param.cmpnyNm = cmpnyNm;
		param.cmpnyNmAbrv = cmpnyNmAbrv;
		param.cmpnyCd = cmpnyCd;
		param.webConectAddr = webConectAddr;
		param.webSj = webSj;
		param.emailDomn = emailDomn;
		param.useLangCd = useLangCd;
		param.sortSn = sortSn ? Number(sortSn) : 1;
		param.enabledYn = 'Y'; // enabledYn; @TODO :: 나중에 변경
		param.useYn = useYn;
		param.delYn = 'N'; //delYn;
		param.trnsmrNm = trnsmrNm;
		param.trnsmrEmailAddr = trnsmrEmailAddr;
		param.smtpSvrUseYn = smtpSvrUseYn;
		param.smtpSvrDomn = smtpSvrDomn;
		param.smtpPortNo = smtpPortNo;
		param.smtpId = smtpId;
		param.smtpPwd = smtpPwd;
		param.cmpnyZipcd = cmpnyZipcd;
		param.cmpnyAddr = cmpnyAddr;
		param.cmpnyDtlAddr = cmpnyDtlAddr;
		param.telno1 = telno1;
		param.photoFilePath = '';
		param.cmpnyNmLangList = cmpnyNmLangList;
		
		//console.log("param", param);
		setCompanyInfo(param);
	}
	
	let setCompanyInfo = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/company/manage/info/set', JSON.stringify(param), 'application/json', true, function (res) {
			let retObj = res.data;
			if( retObj ){
				if(g_roleType === G_MASTER_CODE) {
					let index = 0;
					cp.sb_cmpnyGridData.resources.forEach(function(ele, i){
						if( ele.cmpnyId === retObj.cmpnyId) { index = i; }
					});

					cp.sb_cmpnyGridData.resources[index] = retObj;
					cp.cmpnyGridId.refresh();

					getCompanyList({});
				}
				alert("저장되었습니다.");
			}
		}, function (res) {
			ocb.cmm.errMsgHandler(res);
			alert("저장하는데 실패하였습니다.");
		});
	}

	// [API] 회사 삭제
	let removeCompanyInfo = function(param){
		ocb.restcli.exchangeAsync('POST', page_context_path + '/rest/company/manage/info/remove', JSON.stringify(param), 'application/json', true, function (res) {
			getSelectboxCompanyList({});
			cp.fnChangeSearch();
			$('#cmpnyDetailArea').css('visibility', 'hidden');	// 상세 정보 hide
			$('#smtpUseYnTrArea').hide();

			alert('삭제하였습니다.');
		}, function (res) {
			ocb.cmm.errMsgHandler(res);
			alert('삭제 실패하였습니다.');
		});
	}
	
	// 회사목록 Grid 생성
	let createCmpnyListGrid = function(){
		cp.cmpnyGridProperties.parentid = 'cmpnyGridArea';
		cp.cmpnyGridProperties.id = 'companyMgtEx.cmpnyGridId';
		cp.cmpnyGridProperties.jsonref = 'companyMgtEx.sb_cmpnyGridData.resources';
		cp.cmpnyGridProperties.rowheight = '40';
		cp.cmpnyGridProperties.fixedrowheight = '40';
		cp.cmpnyGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		cp.cmpnyGridProperties.columns = cmpnyListGridColumns();
		cp.cmpnyGridId = _SBGrid.create(cp.cmpnyGridProperties);
	};
	
	// 회사 상세 정보 회사 이름 Grid 생성
	let createCmpnyNmGrid = function(){
		cp.cmpnyNmGridProperties.parentid = 'cmpnyNmGridArea';
		cp.cmpnyNmGridProperties.id = 'companyMgtEx.cmpnyNmGridId';
		cp.cmpnyNmGridProperties.jsonref = 'companyMgtEx.sb_cmpnyNmGridData.resources';
		cp.cmpnyNmGridProperties.rowheight = '40';
		cp.cmpnyNmGridProperties.fixedrowheight = '40';
		cp.cmpnyNmGridProperties.emptyrecords = "데이터가 존재하지 않습니다.";
		cp.cmpnyNmGridProperties.columns = cmpnyNmGridColumns();
		cp.cmpnyNmGridId = _SBGrid.create(cp.cmpnyNmGridProperties);
	};
	
	// 회사 목록 Grid columns
	let cmpnyListGridColumns = function(){
		return [
			{
				caption : ['']
				, ref : 'chkYn'
				, width : '10%'
				, style : 'text-align:center'
				, type : 'checkbox'
				, typeinfo : {
					/*checkedvalue : true
					, uncheckedvalue : false
					, fixedcellcheckbox : { 
						usemode : true
						, rowindex : 0
						, deletecaption : true 
					}*/
					fixedcellcheckbox : { 
						usemode : true
						, rowindex : 0
					}
				}
			}
			, {
				caption : [g_msg.gridCol.cmpnyCd] //['회사코드']
				, ref : 'cmpnyCd'
				, width : '35%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_msg.gridCol.cmpnyNm] //['회사명']
				, ref : 'cmpnyNm'
				, width : '35%'
				, style : 'text-align:center'
				, type : 'output'
			}
			, {
				caption : [g_msg.gridCol.useYn] //['사용여부']
				, ref : 'useYn'
				, width : '20%'
				, style : 'text-align:center'
				, type : 'output'
				, format : { 
					type :'custom'
					, callback : function (val){ 	//cmpnyUseYnText
						return val === 'Y' ? g_msg.useY :  g_msg.useN;
					} 
				}  
			}
		];
	}

	// 회사 이름 Grid columns
	let cmpnyNmGridColumns = function(){
		return [
			{
				caption : [g_msg.gridCol.langCd]
				, ref : 'langCd'
				, width : '30%'//'90px'
				, style : 'text-align:center'
				, type : 'output'
				, format : { 
					type :'custom'
					, callback : formatCmpnyNmLangText
				}  
			}
			, {
				caption :  [g_msg.gridCol.cmpnyNm]
				, ref : 'cmpnyNm'
				, width : '70%'//'150px'
				, style : 'text-align:center'
				, type : 'input'
				, typeinfo : {
					maxlength : 30
				}
			}			
		];
	}

	let formatCmpnyNmLangText = function(val){
		let text = '';
		switch(val){
			case 'kr':
				text = g_msg.langCd.kr;
				break;
			case 'en':
				text = g_msg.langCd.en;
				break;
			default:
				break;
		}
		return text;
	}
	
	// smtp 정보  show / hide
	let setSmtpUseAreaHiddenYn = function(hiddenYn){
		if( hiddenYn ){
			$('#smtpUseYnTrArea').hide();
		}else{
			$('#smtpUseYnTrArea').show();
		}
	}
	
	cp.fnClickSaveBtn = function(){
		getCmpnyDetailInfo();
	}

	cp.fnClickCompanyAddBtn = function(){
		$("#cmpnyDetailArea").css('visibility', 'visible');
		setCmpnyDetailInfo();
	}

	// 상세 정보에서 삭제
	cp.fnClickCompanyRemoveBtn = function(){
		let selIndex = cp.cmpnyGridId.getRow();
		if( selIndex <= 0 ) { return; }

		let selData = cp.cmpnyGridId.getRowData(selIndex);
		if(confirm("선택한 회사를 삭제하시겠습니까?")){
			let param = {}; // { cmpnyId : 'II' };
			
			let removeList = [];
			selData.delYn = 'Y';
			removeList.push($.extend(true, {}, selData));
			
			param.cmpnyList = removeList;
			removeCompanyInfo(param);
		}else{
			return false;
		}
	};

	// 목록에서 check 후 삭제
	cp.fnClickCompanyChkRemoveBtn = function(){
		let ckhList = cp.cmpnyGridId.getCheckedRowData(0);
		if( ckhList.length <= 0 ) {
			alert('삭제할 회사를 선택해 주세요.');
			return false;
		}
		
		if(confirm("선택한 회사를 삭제하시겠습니까?")){
			let removeList = [];
			ckhList.forEach(function(ele){
				ele.data.delYn = 'Y';
				removeList.push($.extend(true, {}, ele.data));
			})
			removeCompanyInfo({ cmpnyList : removeList });
		}else{
			return false;
		}
	}

	cp.fnChangeSmtpUseYn = function(val) {
		setSmtpUseAreaHiddenYn(val === "N");
	}

	cp.fnChangeSearch = function(val){
		let param = {};
		param.cmpnyId = SBUxMethod.getValue('select_cmpny');
		param.useYn = SBUxMethod.getValue('select_useYn');
		getGridCompanyList(param);
	}

	return cp;
})();